#!/usr/bin/env python3
"""
Test script to demonstrate the AI Finance Optimizer API functionality
"""

import requests
import json

# API Configuration
BASE_URL = "http://localhost:8001"
DEMO_EMAIL = "demo@fin.com"
DEMO_PASSWORD = "finpass"

def test_api():
    """Test all API endpoints"""
    print("🤖 AI Finance Optimizer - API Test")
    print("=" * 50)
    
    # Test 1: Health Check
    print("\n1️⃣ Testing Health Check...")
    response = requests.get(f"{BASE_URL}/health")
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Health: {data['message']}")
        print(f"   Version: {data['version']}")
    else:
        print(f"❌ Health check failed: {response.status_code}")
        return
    
    # Test 2: Login
    print("\n2️⃣ Testing Authentication...")
    login_data = {
        "email": DEMO_EMAIL,
        "password": DEMO_PASSWORD
    }
    response = requests.post(f"{BASE_URL}/auth/login", json=login_data)
    if response.status_code == 200:
        data = response.json()
        token = data['token']
        user = data['user']
        print(f"✅ Login successful!")
        print(f"   User: {user['full_name']} ({user['email']})")
        print(f"   Token: {token[:20]}...")
    else:
        print(f"❌ Login failed: {response.status_code}")
        return
    
    # Test 3: Get Insights
    print("\n3️⃣ Testing Financial Insights...")
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(f"{BASE_URL}/finance/insights", headers=headers)
    if response.status_code == 200:
        data = response.json()
        kpis = data['kpis']
        print(f"✅ Insights retrieved!")
        print(f"   Total Spend: ₹{kpis['total_spend']:,}")
        print(f"   Subscriptions: {kpis['total_subscriptions']}")
        print(f"   Anomalies: {kpis['total_anomalies']}")
        print(f"   Projected Savings: ₹{kpis['projected_savings']:,}")
    else:
        print(f"❌ Insights failed: {response.status_code}")
    
    # Test 4: Get Subscriptions
    print("\n4️⃣ Testing Subscription Detection...")
    response = requests.get(f"{BASE_URL}/finance/subscriptions", headers=headers)
    if response.status_code == 200:
        subscriptions = response.json()
        print(f"✅ Found {len(subscriptions)} subscriptions:")
        for sub in subscriptions:
            print(f"   • {sub['merchant']}: ₹{sub['avg_amount']} ({sub['cadence_days']} days)")
    else:
        print(f"❌ Subscriptions failed: {response.status_code}")
    
    # Test 5: Get Anomalies
    print("\n5️⃣ Testing Anomaly Detection...")
    response = requests.get(f"{BASE_URL}/finance/anomalies", headers=headers)
    if response.status_code == 200:
        anomalies = response.json()
        print(f"✅ Found {len(anomalies)} anomalies:")
        for anomaly in anomalies:
            print(f"   • {anomaly['merchant']}: ₹{anomaly['amount']:,} ({anomaly['reason'][:50]}...)")
    else:
        print(f"❌ Anomalies failed: {response.status_code}")
    
    # Test 6: Generate Savings Plan
    print("\n6️⃣ Testing Budget Optimization...")
    plan_data = {"savings_goal": 5000}
    response = requests.post(f"{BASE_URL}/finance/plan", json=plan_data, headers=headers)
    if response.status_code == 200:
        plan = response.json()
        print(f"✅ Plan generated!")
        print(f"   Goal: ₹{plan['goal']:,}")
        print(f"   Projected Savings: ₹{plan['projected_savings']:,}")
        print(f"   Goal Met: {'✅' if plan['met'] else '❌'}")
        print(f"   Actions: {len(plan['actions'])}")
        for action in plan['actions'][:3]:  # Show first 3 actions
            print(f"     • {action['kind'].title()} {action['target']}: ₹{action['save_amount']} saved")
    else:
        print(f"❌ Plan generation failed: {response.status_code}")
    
    # Test 7: What-If Analysis
    print("\n7️⃣ Testing What-If Analysis...")
    whatif_data = {"savings_goal": 3000}
    response = requests.post(f"{BASE_URL}/finance/whatif", json=whatif_data, headers=headers)
    if response.status_code == 200:
        whatif = response.json()
        print(f"✅ What-If analysis completed!")
        print(f"   New Goal: ₹{whatif['goal']:,}")
        print(f"   New Savings: ₹{whatif['projected_savings']:,}")
        print(f"   Goal Met: {'✅' if whatif['met'] else '❌'}")
    else:
        print(f"❌ What-If analysis failed: {response.status_code}")
    
    print("\n" + "=" * 50)
    print("🎉 All tests completed successfully!")
    print("\n📱 Frontend is available at: http://localhost:3000")
    print("📚 API Docs available at: http://localhost:8001/docs")
    print("🔑 Demo credentials: demo@fin.com / finpass")

if __name__ == "__main__":
    try:
        test_api()
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to the API. Make sure it's running on http://localhost:8001")
    except Exception as e:
        print(f"❌ Error: {e}")
