import { useEffect, useState } from 'react';
import { apiClient, DashboardData } from '../lib/api';
import { formatCurrency } from '../lib/format';

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const dashboardData = await apiClient.getDashboard();
      setData(dashboardData);
    } catch (err: any) {
      setError('Failed to load dashboard data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="glass-card p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"></div>
          <p className="mt-4 text-center text-gray-400">Loading your financial insights...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="glass-card p-8 text-center">
        <div className="text-red-400 text-lg mb-4">⚠️ {error}</div>
        <button onClick={loadDashboard} className="btn-primary">
          Try Again
        </button>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="glass-card p-6 bg-gradient-to-r from-primary-900/20 to-accent-900/20">
        <h1 className="text-3xl font-bold text-gradient mb-2">
          🏦 Your Financial Dashboard
        </h1>
        <p className="text-gray-300 text-lg">
          Welcome to your AI-powered finance optimizer! Here's what your money has been up to...
        </p>
      </div>

      {/* KPI Cards - Main Numbers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="glass-card p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-400">Total Spending</h3>
            <span className="text-2xl">💰</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {formatCurrency(data.kpis.total_spend)}
          </div>
          <p className="text-xs text-gray-400 mt-1">Last 30 days</p>
        </div>

        <div className="glass-card p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-400">Subscriptions Found</h3>
            <span className="text-2xl">📱</span>
          </div>
          <div className="text-2xl font-bold text-accent-400">
            {data.kpis.subscriptions_count}
          </div>
          <p className="text-xs text-gray-400 mt-1">Netflix, Spotify, etc.</p>
        </div>

        <div className="glass-card p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-400">Unusual Spending</h3>
            <span className="text-2xl">⚠️</span>
          </div>
          <div className="text-2xl font-bold text-yellow-400">
            {data.kpis.anomalies_count}
          </div>
          <p className="text-xs text-gray-400 mt-1">Transactions to review</p>
        </div>

        <div className="glass-card p-6 hover:scale-105 transition-transform">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-gray-400">Potential Savings</h3>
            <span className="text-2xl">💚</span>
          </div>
          <div className="text-2xl font-bold text-green-400">
            {formatCurrency(data.kpis.projected_savings)}
          </div>
          <p className="text-xs text-gray-400 mt-1">Per month if optimized</p>
        </div>
      </div>

      {/* Explanatory Section */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <span className="text-2xl mr-3">🤖</span>
          What This AI Software Does For You
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-primary-400 mb-2">🔍 Smart Analysis</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Automatically categorizes your spending</li>
              <li>• Detects recurring subscriptions</li>
              <li>• Finds unusual transactions</li>
              <li>• Tracks spending trends over time</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-primary-400 mb-2">💡 Money-Saving Actions</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Cancel unused subscriptions</li>
              <li>• Find cheaper alternatives</li>
              <li>• Set spending limits by category</li>
              <li>• Create personalized savings plans</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Where Your Money Goes */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">📊</span>
          Where Your Money Goes
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Object.entries(data.category_breakdown).map(([category, amount]) => (
            <div key={category} className="bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="text-sm text-gray-400 mb-1">{category}</div>
              <div className="font-semibold">{formatCurrency(amount)}</div>
              <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                <div 
                  className="bg-primary-500 h-2 rounded-full"
                  style={{
                    width: `${Math.min((amount / Math.max(...Object.values(data.category_breakdown))) * 100, 100)}%`
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Subscriptions Found */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">🔄</span>
          Recurring Subscriptions Found
        </h2>
        <div className="space-y-4">
          {data.top_subscriptions.map((sub, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-4 border border-white/10 flex justify-between items-center">
              <div>
                <div className="font-medium">{sub.merchant}</div>
                <div className="text-sm text-gray-400">
                  Every {sub.cadence_days} days • {sub.total_transactions} payments detected
                </div>
              </div>
              <div className="text-right">
                <div className="font-semibold">{formatCurrency(sub.avg_amount)}</div>
                <div className="text-sm text-gray-400">per month</div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
          <p className="text-green-400 text-sm">
            💡 <strong>Tip:</strong> Review these subscriptions - canceling unused ones could save you money!
          </p>
        </div>
      </div>

      {/* Unusual Transactions */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">⚠️</span>
          Unusual Spending Detected
        </h2>
        <div className="space-y-4">
          {data.recent_anomalies.map((anomaly, index) => (
            <div key={index} className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="font-medium">{anomaly.merchant}</div>
                  <div className="text-sm text-gray-400">{anomaly.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-yellow-400">{formatCurrency(anomaly.amount)}</div>
                  <div className="text-xs text-gray-400">Expected: {anomaly.expected_range}</div>
                </div>
              </div>
              <div className="text-sm text-yellow-300">{anomaly.reason}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <p className="text-yellow-400 text-sm">
            💡 <strong>Review these transactions:</strong> Make sure they're legitimate and understand why they're higher than usual.
          </p>
        </div>
      </div>

      {/* Call to Action */}
      <div className="glass-card p-6 bg-gradient-to-r from-green-900/20 to-primary-900/20 border-green-500/20">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <span className="text-2xl mr-3">🎯</span>
          Ready to Save Money?
        </h2>
        <p className="text-gray-300 mb-4">
          Based on your spending patterns, we can help you save <strong className="text-green-400">{formatCurrency(data.kpis.projected_savings)}</strong> per month!
        </p>
        <div className="flex gap-4">
          <button 
            onClick={() => window.location.href = '/planner'}
            className="btn-primary"
          >
            Create My Savings Plan 🚀
          </button>
          <button 
            onClick={() => alert('Upload feature coming soon! For now, we\'re using demo data.')}
            className="btn-secondary"
          >
            Upload Bank Statement 📄
          </button>
        </div>
      </div>

      {/* How It Works */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">❓</span>
          How This Works
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-4xl mb-3">📤</div>
            <h3 className="font-medium mb-2">1. Upload Data</h3>
            <p className="text-sm text-gray-400">
              Upload your bank statements (CSV/Excel) or connect your bank account
            </p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">🤖</div>
            <h3 className="font-medium mb-2">2. AI Analysis</h3>
            <p className="text-sm text-gray-400">
              Our AI categorizes transactions, finds patterns, and detects anomalies
            </p>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-3">💰</div>
            <h3 className="font-medium mb-2">3. Save Money</h3>
            <p className="text-sm text-gray-400">
              Get personalized recommendations to optimize your spending and reach savings goals
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
