import { useState } from 'react';
import { apiClient, SavingsPlan } from '../lib/api';
import { formatCurrency } from '../lib/format';

export default function Planner() {
  const [goalAmount, setGoalAmount] = useState<string>('10000');
  const [goalMonths, setGoalMonths] = useState<string>('12');
  const [plan, setPlan] = useState<SavingsPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const generatePlan = async () => {
    if (!goalAmount || !goalMonths) {
      setError('Please enter both savings goal and timeframe');
      return;
    }

    const amount = parseFloat(goalAmount);
    const months = parseInt(goalMonths);

    if (amount <= 0 || months <= 0) {
      setError('Please enter valid positive numbers');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const newPlan = await apiClient.createSavingsPlan({
        goal_amount: amount,
        goal_months: months
      });
      setPlan(newPlan);
    } catch (err: any) {
      setError('Failed to generate savings plan. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="glass-card p-6 bg-gradient-to-r from-green-900/20 to-primary-900/20">
        <h1 className="text-3xl font-bold text-gradient mb-2">
          🎯 Smart Budget Planner
        </h1>
        <p className="text-gray-300 text-lg">
          Set your savings goal and get a personalized plan to achieve it!
        </p>
      </div>

      {/* Goal Input */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">💰</span>
          What's Your Savings Goal?
        </h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              How much do you want to save?
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">₹</span>
              <input
                type="number"
                value={goalAmount}
                onChange={(e) => setGoalAmount(e.target.value)}
                className="w-full pl-8 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-primary-500 focus:outline-none"
                placeholder="10,000"
                min="1"
              />
            </div>
            <p className="text-xs text-gray-400 mt-1">Enter amount in Indian Rupees (₹)</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              In how many months?
            </label>
            <input
              type="number"
              value={goalMonths}
              onChange={(e) => setGoalMonths(e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-primary-500 focus:outline-none"
              placeholder="12"
              min="1"
            />
            <p className="text-xs text-gray-400 mt-1">Target timeframe in months</p>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={generatePlan}
            disabled={loading}
            className="btn-primary w-full md:w-auto"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Creating Your Plan...
              </>
            ) : (
              <>Generate My Savings Plan 🚀</>
            )}
          </button>
        </div>

        {error && (
          <div className="mt-4 p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400">
            {error}
          </div>
        )}
      </div>

      {/* Example Goals */}
      {!plan && (
        <div className="glass-card p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <span className="text-xl mr-2">💡</span>
            Popular Savings Goals
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Emergency Fund', amount: 50000, months: 12 },
              { label: 'Vacation', amount: 25000, months: 6 },
              { label: 'New Phone', amount: 15000, months: 4 },
              { label: 'Car Down Payment', amount: 100000, months: 18 },
            ].map((goal) => (
              <button
                key={goal.label}
                onClick={() => {
                  setGoalAmount(goal.amount.toString());
                  setGoalMonths(goal.months.toString());
                }}
                className="p-4 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors text-left"
              >
                <div className="font-medium text-sm">{goal.label}</div>
                <div className="text-primary-400 font-semibold">{formatCurrency(goal.amount)}</div>
                <div className="text-xs text-gray-400">{goal.months} months</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Generated Plan */}
      {plan && (
        <>
          {/* Plan Summary */}
          <div className="glass-card p-6 bg-gradient-to-r from-green-900/20 to-blue-900/20 border-green-500/20">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <span className="text-2xl mr-3">📋</span>
              Your Personalized Savings Plan
            </h2>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">
                  {formatCurrency(plan.monthly_target)}
                </div>
                <div className="text-sm text-gray-400">Monthly Savings Target</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">
                  {formatCurrency(plan.goal_amount)}
                </div>
                <div className="text-sm text-gray-400">Total Goal</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">
                  {plan.goal_months}
                </div>
                <div className="text-sm text-gray-400">Months to Goal</div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
              <h3 className="font-semibold text-green-400 mb-2">✅ Good News!</h3>
              <p className="text-gray-300 text-sm">
                Based on your spending patterns, this goal is <strong>achievable</strong>! 
                The recommended actions below will help you save {formatCurrency(plan.monthly_target)} per month.
              </p>
            </div>
          </div>

          {/* Action Plan */}
          <div className="glass-card p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <span className="text-2xl mr-3">⚡</span>
              Action Plan: How to Save {formatCurrency(plan.monthly_target)}/Month
            </h2>
            
            <div className="space-y-4">
              {plan.recommended_actions.map((action, index) => (
                <div key={index} className="bg-white/5 border border-white/10 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h3 className="font-medium text-primary-400">{action.category}</h3>
                      <p className="text-gray-300 text-sm mt-1">{action.description}</p>
                    </div>
                    <div className="text-right ml-4">
                      <div className="text-green-400 font-semibold">
                        +{formatCurrency(action.monthly_savings)}
                      </div>
                      <div className="text-xs text-gray-400">monthly savings</div>
                    </div>
                  </div>
                  
                  {/* Pain Score Indicator */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">
                      Difficulty: {action.pain_score < 3 ? '😊 Easy' : action.pain_score < 7 ? '😐 Moderate' : '😫 Challenging'}
                    </span>
                    <div className="flex items-center space-x-1">
                      {[...Array(10)].map((_, i) => (
                        <div
                          key={i}
                          className={`w-2 h-2 rounded-full ${
                            i < action.pain_score ? 'bg-yellow-400' : 'bg-gray-600'
                          }`}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <h3 className="font-semibold text-blue-400 mb-2">💡 Pro Tips</h3>
              <ul className="text-gray-300 text-sm space-y-1">
                <li>• Start with the easiest actions first to build momentum</li>
                <li>• Set up automatic transfers to your savings account</li>
                <li>• Review and adjust your plan monthly</li>
                <li>• Use a separate account for your savings goal to avoid temptation</li>
              </ul>
            </div>
          </div>

          {/* Progress Tracker */}
          <div className="glass-card p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <span className="text-2xl mr-3">📈</span>
              Progress Tracker
            </h2>
            
            <div className="bg-gray-700 rounded-full h-4 mb-4">
              <div className="bg-gradient-to-r from-green-500 to-blue-500 h-4 rounded-full w-0"></div>
            </div>
            <div className="flex justify-between text-sm text-gray-400">
              <span>₹0</span>
              <span className="text-primary-400">Month 1 starts now!</span>
              <span>{formatCurrency(plan.goal_amount)}</span>
            </div>

            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-lg font-semibold text-white">0</div>
                <div className="text-xs text-gray-400">Days</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-white">₹0</div>
                <div className="text-xs text-gray-400">Saved</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-white">{plan.goal_months}</div>
                <div className="text-xs text-gray-400">Months Left</div>
              </div>
              <div className="text-center">
                <div className="text-lg font-semibold text-white">0%</div>
                <div className="text-xs text-gray-400">Complete</div>
              </div>
            </div>
          </div>

          {/* What-If Analysis */}
          <div className="glass-card p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <span className="text-2xl mr-3">🔮</span>
              What If You Save More?
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h3 className="font-medium text-green-400 mb-3">If you save 25% more per month:</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Monthly Savings:</span>
                    <span className="text-white">{formatCurrency(plan.monthly_target * 1.25)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Goal reached in:</span>
                    <span className="text-green-400">{Math.ceil(plan.goal_months * 0.8)} months</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Time saved:</span>
                    <span className="text-green-400">{Math.floor(plan.goal_months * 0.2)} months early!</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <h3 className="font-medium text-blue-400 mb-3">If you extend timeline by 6 months:</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">New timeline:</span>
                    <span className="text-white">{plan.goal_months + 6} months</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Monthly Savings:</span>
                    <span className="text-blue-400">{formatCurrency(plan.goal_amount / (plan.goal_months + 6))}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Reduction:</span>
                    <span className="text-blue-400">-{formatCurrency(plan.monthly_target - (plan.goal_amount / (plan.goal_months + 6)))}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Start Over */}
          <div className="glass-card p-6 text-center">
            <h3 className="text-lg font-semibold mb-4">Want to adjust your goal?</h3>
            <button
              onClick={() => {
                setPlan(null);
                setError('');
              }}
              className="btn-secondary"
            >
              Create New Plan
            </button>
          </div>
        </>
      )}

      {/* How the AI Works */}
      <div className="glass-card p-6">
        <h2 className="text-xl font-semibold mb-6 flex items-center">
          <span className="text-2xl mr-3">🧠</span>
          How Our AI Creates Your Plan
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-primary-400 mb-2">🔍 Spending Analysis</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Analyzes your transaction history</li>
              <li>• Identifies subscription services</li>
              <li>• Finds discretionary vs. essential spending</li>
              <li>• Detects seasonal patterns</li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-primary-400 mb-2">🎯 Smart Recommendations</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Prioritizes low-pain, high-impact changes</li>
              <li>• Considers your lifestyle preferences</li>
              <li>• Balances feasibility with savings goals</li>
              <li>• Adapts to your spending personality</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
