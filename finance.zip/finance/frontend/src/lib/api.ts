import axios, { AxiosInstance } from 'axios';

// Types
export interface AuthResponse {
  access_token: string;
  token_type: string;
  user_id: number;
  email: string;
}


export interface User {
  id: number;
  email: string;
  full_name?: string;
}

export interface DashboardData {
  kpis: {
    total_spend: number;
    subscriptions_count: number;
    anomalies_count: number;
    projected_savings: number;
    transaction_count: number;
  };
  category_breakdown: Record<string, number>;
  monthly_trend: Array<{
    month: string;
    amount: number;
    transactions: number;
  }>;
  top_subscriptions: Subscription[];
  recent_anomalies: Anomaly[];
  accounts: Account[];
}

export interface Subscription {
  merchant: string;
  avg_amount: number;
  cadence_days: number;
  last_transaction: string;
  total_transactions: number;
  confidence: number;
}

export interface Anomaly {
  transaction_id: number;
  date: string;
  merchant: string;
  amount: number;
  expected_range: string;
  anomaly_score: number;
  reason: string;
}

export interface Account {
  id: number;
  name: string;
  account_type: string;
  currency: string;
}

export interface Plan {
  id: number;
  month: string;
  savings_goal: number;
  projected_savings: number;
  goal_met: boolean;
  actions: PlanAction[];
}

export interface PlanAction {
  type: string;
  target: string;
  description: string;
  save_amount: number;
  pain_score: number;
  efficiency?: number;
}

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: (typeof window !== 'undefined' && (window as any).__API_URL__) || (import.meta as any).env?.VITE_API_URL || 'http://localhost:8000',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add auth interceptor
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('auth_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    // Response interceptor for auth errors
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          this.clearAuth();
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Auth methods
  async login(email: string, password: string): Promise<AuthResponse> {
    const response = await this.client.post<AuthResponse>('/auth/login', {
      email,
      password,
    });
    this.setAuth(response.data.access_token);
    return response.data;
  }

  async register(email: string, password: string, full_name?: string): Promise<AuthResponse> {
    const response = await this.client.post<AuthResponse>('/auth/register', {
      email,
      password,
      full_name,
    });
    this.setAuth(response.data.access_token);
    return response.data;
  }

  setAuth(token: string) {
    localStorage.setItem('auth_token', token);
  }

  clearAuth() {
    localStorage.removeItem('auth_token');
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('auth_token');
  }

  // Dashboard
  async getDashboard(): Promise<DashboardData> {
    const response = await this.client.get<DashboardData>('/finance/dashboard');
    return response.data;
  }

  // Insights
  async getInsights(windowDays: number = 30) {
    const response = await this.client.get('/finance/insights', {
      params: { window: windowDays },
    });
    return response.data;
  }

  // Subscriptions
  async getSubscriptions(): Promise<Subscription[]> {
    const response = await this.client.get<Subscription[]>('/finance/subscriptions');
    return response.data;
  }

  // Anomalies
  async getAnomalies(): Promise<Anomaly[]> {
    const response = await this.client.get<Anomaly[]>('/finance/anomalies');
    return response.data;
  }

  // Plans
  async createPlan(savingsGoal: number, caps?: Record<string, number>): Promise<Plan> {
    const response = await this.client.post<Plan>('/finance/plan', {
      savings_goal: savingsGoal,
      caps,
    });
    return response.data;
  }

  async whatIfAnalysis(savingsGoal: number, caps?: Record<string, number>) {
    const response = await this.client.post('/finance/whatif', {
      savings_goal: savingsGoal,
      caps,
    });
    return response.data;
  }

  // Accounts
  async getAccounts(): Promise<Account[]> {
    const response = await this.client.get<Account[]>('/finance/accounts');
    return response.data;
  }

  async createAccount(name: string, accountType: string, currency: string = 'INR'): Promise<Account> {
    const response = await this.client.post<Account>('/finance/accounts', {
      name,
      account_type: accountType,
      currency,
    });
    return response.data;
  }

  // Transactions
  async getTransactions(limit: number = 100, offset: number = 0) {
    const response = await this.client.get('/finance/transactions', {
      params: { limit, offset },
    });
    return response.data;
  }

  async uploadTransactions(file: File, accountId: number) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('account_id', accountId.toString());

    const response = await this.client.post('/finance/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  }

  // Categories
  async getCategories() {
    const response = await this.client.get('/finance/categories');
    return response.data;
  }

  // Demo/Development
  async seedDemo() {
    const response = await this.client.post('/finance/seed');
    return response.data;
  }

  // Utility
  async clearCache() {
    const response = await this.client.delete('/finance/cache');
    return response.data;
  }
}

export const apiClient = new ApiClient();