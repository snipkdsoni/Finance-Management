import { ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { apiClient } from '../lib/api';

interface LayoutProps {
  children: ReactNode;
  onLogout: () => void;
}

export default function Layout({ children, onLogout }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const navigation = [
    { path: '/dashboard', label: 'Dashboard', icon: '🏠' },
    { path: '/planner', label: 'Budget Planner', icon: '🎯' },
    { path: '/insights', label: 'Insights', icon: '📊' },
    { path: '/upload', label: 'Upload Data', icon: '📤' },
  ];

  const handleLogout = () => {
    apiClient.logout();
    onLogout();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900">
      {/* Navigation Header */}
      <nav className="glass-card m-4 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl font-bold text-gradient">
              💰 FinanceAI
            </div>
            <div className="text-sm text-gray-400">
              Your Personal Finance Optimizer
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              {navigation.map((item) => (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    location.pathname === item.path
                      ? 'bg-primary-600 text-white shadow-lg'
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <span className="mr-2">{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </div>

            <button
              onClick={handleLogout}
              className="px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-red-500/20 border border-red-500/30"
            >
              🚪 Logout
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="p-4 pb-8">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="glass-card m-4 mt-8 p-6">
        <div className="text-center text-gray-400">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-white mb-2">🤖 AI-Powered Personal Finance</h3>
            <p className="text-sm max-w-2xl mx-auto">
              This demo showcases advanced financial analysis algorithms including subscription detection, 
              anomaly identification, intelligent categorization, and personalized budget optimization. 
              All data shown is simulated for demonstration purposes.
            </p>
          </div>
          
          <div className="border-t border-white/10 pt-4">
            <div className="flex justify-center items-center space-x-6 text-xs">
              <div className="flex items-center space-x-2">
                <span>🔒</span>
                <span>Bank-grade Security</span>
              </div>
              <div className="flex items-center space-x-2">
                <span>🤖</span>
                <span>AI-Powered Insights</span>
              </div>
              <div className="flex items-center space-x-2">
                <span>📊</span>
                <span>Real-time Analysis</span>
              </div>
              <div className="flex items-center space-x-2">
                <span>💡</span>
                <span>Personalized Recommendations</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
