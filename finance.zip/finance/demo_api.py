#!/usr/bin/env python3
"""
Demo API Server for Personal Finance Optimizer
This serves mock data that demonstrates the application functionality.
"""

import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

app = FastAPI(
    title="AI Finance Optimizer Demo",
    version="1.0.0",
    description="AI-Powered Personal Finance Optimizer with transaction analysis and budget planning"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    # Dev: allow all origins to support LAN IPs and dynamic Vite ports (5173+)
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock authentication
security = HTTPBearer()
MOCK_TOKEN = "demo_token_123"

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != MOCK_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    return credentials.credentials

# Pydantic models
class UserLogin(BaseModel):
    email: str
    password: str

class UserRegister(BaseModel):
    email: str
    password: str
    full_name: str

class PlanRequest(BaseModel):
    savings_goal: float

# Mock data
def generate_demo_data():
    """Generate realistic demo financial data."""
    categories = ["Food & Dining", "Shopping", "Entertainment", "Transportation", "Bills & Utilities", "Health & Medical", "Travel", "Education"]
    
    # Spending breakdown by category
    category_breakdown = {
        "Food & Dining": 12500,
        "Shopping": 8900,
        "Bills & Utilities": 6500,
        "Transportation": 4200,
        "Entertainment": 3800,
        "Health & Medical": 2100,
        "Travel": 1500,
        "Education": 1000
    }
    
    # Mock subscriptions
    subscriptions = [
        {
            "merchant": "Netflix",
            "avg_amount": 799,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.95
        },
        {
            "merchant": "Spotify",
            "avg_amount": 119,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.92
        },
        {
            "merchant": "Amazon Prime",
            "avg_amount": 1499,
            "cadence_days": 365,
            "total_transactions": 1,
            "confidence": 0.88
        },
        {
            "merchant": "Gym Membership",
            "avg_amount": 2000,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.94
        }
    ]
    
    # Mock anomalies
    anomalies = [
        {
            "merchant": "Electronics Store",
            "amount": 45000,
            "date": "2024-01-15",
            "expected_range": "₹2,000-₹5,000",
            "reason": "Amount is 8x higher than typical electronics purchases",
            "confidence": 0.89
        },
        {
            "merchant": "Restaurant",
            "amount": 8500,
            "date": "2024-01-10",
            "expected_range": "₹500-₹2,000", 
            "reason": "Unusually expensive meal - possibly group dining or special occasion",
            "confidence": 0.76
        },
        {
            "merchant": "Online Shopping",
            "amount": 12000,
            "date": "2024-01-08",
            "expected_range": "₹1,000-₹3,000",
            "reason": "Large purchase - check if this was intentional",
            "confidence": 0.82
        }
    ]
    
    return {
        "categories": categories,
        "category_breakdown": category_breakdown,
        "subscriptions": subscriptions,
        "anomalies": anomalies
    }


def generate_dashboard_payload():
    """Return payload shaped exactly like the frontend Dashboard expects."""
    data = generate_demo_data()
    # Monthly trend as array of {month, amount, transactions}
    monthly_trend = [
        {"month": "2024-02", "amount": 8234.50, "transactions": 245},
        {"month": "2024-03", "amount": 7890.20, "transactions": 223},
        {"month": "2024-04", "amount": 8567.80, "transactions": 267},
        {"month": "2024-05", "amount": 7234.00, "transactions": 198},
        {"month": "2024-06", "amount": 8905.50, "transactions": 289},
        {"month": "2024-07", "amount": 4399.50, "transactions": 165},
    ]

    # Map subscriptions/anomalies to the legacy shapes the UI uses
    top_subscriptions = [
        {
            "merchant": s["merchant"],
            "avg_amount": s["avg_amount"],
            "cadence_days": s["cadence_days"],
            "last_transaction": "2024-07-15",
            "total_transactions": s["total_transactions"],
            "confidence": s["confidence"],
        }
        for s in data["subscriptions"]
    ]

    recent_anomalies = [
        {
            "transaction_id": i + 1,
            "date": a["date"],
            "merchant": a["merchant"],
            "amount": a["amount"],
            "expected_range": a.get("expected_range", "₹1,000-₹5,000"),
            "anomaly_score": round(3.5 + i * 0.3, 2),
            "reason": a["reason"],
        }
        for i, a in enumerate(data["anomalies"])
    ]

    accounts = [
        {"id": 1, "name": "HDFC Savings", "account_type": "savings", "currency": "INR"}
    ]

    dashboard = {
        "kpis": {
            "total_spend": sum(data["category_breakdown"].values()),
            "subscriptions_count": len(top_subscriptions),
            "anomalies_count": len(recent_anomalies),
            "projected_savings": 8650.00,
            "transaction_count": 1387,
        },
        "category_breakdown": data["category_breakdown"],
        "monthly_trend": monthly_trend,
        "top_subscriptions": top_subscriptions,
        "recent_anomalies": recent_anomalies,
        "accounts": accounts,
    }
    return dashboard

# API Endpoints
@app.get("/health")
def health():
    """Health check endpoint"""
    return {
        "status": "ok", 
        "message": "AI Finance Optimizer Demo API is running",
        "version": "1.0.0"
    }

@app.post("/auth/register")
def register(user: UserRegister):
    """Register a new user"""
    return {
        "token": MOCK_TOKEN,
        "user": {
            "id": 1,
            "email": user.email,
            "full_name": user.full_name
        }
    }

@app.post("/auth/login")
def login(user: UserLogin):
    """Login user"""
    if user.email == "demo@fin.com" and user.password == "finpass":
        return {
            "token": MOCK_TOKEN,
            "user": {
                "id": 1,
                "email": user.email,
                "full_name": "Demo User"
            }
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/finance/insights")
def get_insights(window: int = 30, token: str = Depends(verify_token)):
    """Get financial insights and KPIs"""
    data = generate_demo_data()
    
    total_spend = sum(data["category_breakdown"].values())
    total_subscriptions = len(data["subscriptions"])
    total_anomalies = len(data["anomalies"])
    
    return {
        "kpis": {
            "total_spend": total_spend,
            "total_subscriptions": total_subscriptions,
            "total_anomalies": total_anomalies,
            "projected_savings": 8500
        },
        "category_breakdown": data["category_breakdown"],
        "trends": {
            "labels": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
            "spending": [42000, 38000, 45000, 41000, 39000, 43000],
            "savings": [2000, 3500, 1500, 2800, 4200, 3100]
        }
    }


@app.get("/finance/dashboard")
def get_dashboard(token: str = Depends(verify_token)):
    """Endpoint used by the Dashboard page in the frontend."""
    return generate_dashboard_payload()

@app.get("/finance/subscriptions")
def get_subscriptions(token: str = Depends(verify_token)):
    """Get detected subscriptions"""
    data = generate_demo_data()
    return data["subscriptions"]

@app.get("/finance/anomalies")
def get_anomalies(token: str = Depends(verify_token)):
    """Get detected anomalies"""
    data = generate_demo_data()
    return data["anomalies"]

@app.post("/finance/plan")
def create_plan(plan_request: PlanRequest, token: str = Depends(verify_token)):
    """Create an optimized spending plan – shaped for the frontend Plan interface."""
    savings_goal = float(plan_request.savings_goal)

    raw_actions = [
        {
            "type": "cancel",
            "target": "Spotify Premium",
            "description": "Switch to free tier or family plan",
            "save_amount": 119.0,
            "pain_score": 0.3,
            "efficiency": 20.0,
        },
        {
            "type": "cap",
            "target": "Food & Dining",
            "description": "Reduce dining out from ₹12,500 to ₹10,000",
            "save_amount": 2500.0,
            "pain_score": 0.6,
            "efficiency": 35.0,
        },
        {
            "type": "switch",
            "target": "Gym Membership",
            "description": "Switch to cheaper gym or home workout",
            "save_amount": 500.0,
            "pain_score": 0.4,
            "efficiency": 25.0,
        },
        {
            "type": "cancel",
            "target": "Unused Subscriptions",
            "description": "Cancel unused streaming services",
            "save_amount": 800.0,
            "pain_score": 0.1,
            "efficiency": 50.0,
        },
    ]

    total = sum(a["save_amount"] for a in raw_actions)

    return {
        "id": 1,
        "month": "2024-08",
        "savings_goal": savings_goal,
        "projected_savings": total,
        "goal_met": total >= savings_goal,
        "actions": raw_actions,
    }

@app.post("/finance/whatif")
def what_if_analysis(plan_request: PlanRequest, token: str = Depends(verify_token)):
    """What-if analysis with different parameters"""
    return create_plan(plan_request, token)

@app.post("/finance/upload")
def upload_transactions(token: str = Depends(verify_token)):
    """Upload transactions (mock)"""
    return {
        "imported": 150,
        "message": "Successfully imported 150 transactions"
    }

@app.post("/finance/seed")
def seed_data(token: str = Depends(verify_token)):
    """Seed demo data"""
    return {
        "ok": True,
        "message": "Demo data seeded successfully"
    }

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting AI Finance Optimizer Demo API...")
    print("📊 Available endpoints:")
    print("   - Health: http://localhost:8000/health")
    print("   - API Docs: http://localhost:8000/docs")
    print("   - Demo Login: demo@fin.com / finpass")
    print("   - Token: demo_token_123")
    uvicorn.run(app, host="0.0.0.0", port=8000)
