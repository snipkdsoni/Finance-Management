#!/usr/bin/env python3
"""
Demo API Server for Personal Finance Optimizer Frontend Development

This serves mock data that matches the frontend API client expectations,
allowing for frontend development and demonstration without setting up
the full database infrastructure.
"""

import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Finance AI Demo API", version="1.0.0")

# Add CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock data generators
def generate_demo_data():
    """Generate realistic demo financial data."""
    categories = ["Food & Dining", "Shopping", "Entertainment", "Transportation", "Bills & Utilities", "Health & Medical", "Travel", "Education"]
    
    # Spending breakdown by category
    category_breakdown = {
        "Food & Dining": 12500,
        "Shopping": 8900,
        "Bills & Utilities": 6500,
        "Transportation": 4200,
        "Entertainment": 3800,
        "Health & Medical": 2100,
        "Travel": 1500,
        "Education": 1000
    }
    
    # Mock subscriptions
    subscriptions = [
        {
            "merchant": "Netflix",
            "avg_amount": 799,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.95
        },
        {
            "merchant": "Spotify",
            "avg_amount": 119,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.92
        },
        {
            "merchant": "Amazon Prime",
            "avg_amount": 1499,
            "cadence_days": 365,
            "total_transactions": 1,
            "confidence": 0.88
        },
        {
            "merchant": "Gym Membership",
            "avg_amount": 2000,
            "cadence_days": 30,
            "total_transactions": 6,
            "confidence": 0.94
        }
    ]
    
    # Mock anomalies
    anomalies = [
        {
            "merchant": "Electronics Store",
            "amount": 45000,
            "date": "2024-01-15",
            "expected_range": "₹2,000-₹5,000",
            "reason": "Amount is 8x higher than typical electronics purchases",
            "confidence": 0.89
        },
        {
            "merchant": "Restaurant",
            "amount": 8500,
            "date": "2024-01-10",
            "expected_range": "₹500-₹2,000", 
            "reason": "Unusually expensive meal - possibly group dining or special occasion",
            "confidence": 0.76
        },
        {
            "merchant": "Online Shopping",
            "amount": 12000,
            "date": "2024-01-08",
            "expected_range": "₹1,000-₹4,000",
            "reason": "3x higher than typical online purchases",
            "confidence": 0.82
        }
    ]
    
    return {
        "category_breakdown": category_breakdown,
        "subscriptions": subscriptions,
        "anomalies": anomalies
    }

# Pydantic models for request/response validation
class LoginRequest(BaseModel):
    email: str
    password: str

class RegisterRequest(BaseModel):
    name: str
    email: str
    password: str

class SavingsRequest(BaseModel):
    goal_amount: float
    goal_months: int

class DashboardResponse(BaseModel):
    kpis: Dict[str, Any]
    category_breakdown: Dict[str, float]
    top_subscriptions: List[Dict[str, Any]]
    recent_anomalies: List[Dict[str, Any]]

class SavingsPlanResponse(BaseModel):
    goal_amount: float
    goal_months: int
    monthly_target: float
    recommended_actions: List[Dict[str, Any]]

# Demo data
demo_data = generate_demo_data()

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "Personal Finance AI Demo API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "auth": ["/auth/login", "/auth/register"],
            "dashboard": "/dashboard",
            "savings": "/savings/plan"
        }
    }

@app.post("/auth/login")
async def login(request: LoginRequest):
    """Mock login endpoint."""
    # Accept any credentials for demo
    if request.email and request.password:
        return {
            "access_token": "demo_token_" + request.email.replace("@", "_"),
            "token_type": "bearer",
            "user": {
                "id": 1,
                "email": request.email,
                "name": "Demo User"
            }
        }
    else:
        raise HTTPException(status_code=400, detail="Email and password required")

@app.post("/auth/register")  
async def register(request: RegisterRequest):
    """Mock registration endpoint."""
    if request.name and request.email and request.password:
        return {
            "access_token": "demo_token_" + request.email.replace("@", "_"),
            "token_type": "bearer",
            "user": {
                "id": 2,
                "email": request.email,
                "name": request.name
            }
        }
    else:
        raise HTTPException(status_code=400, detail="Name, email, and password required")

@app.get("/dashboard")
async def get_dashboard():
    """Get dashboard data with financial insights."""
    total_spend = sum(demo_data["category_breakdown"].values())
    
    return DashboardResponse(
        kpis={
            "total_spend": total_spend,
            "subscriptions_count": len(demo_data["subscriptions"]),
            "anomalies_count": len(demo_data["anomalies"]),
            "projected_savings": 3500  # Mock savings potential
        },
        category_breakdown=demo_data["category_breakdown"],
        top_subscriptions=demo_data["subscriptions"],
        recent_anomalies=demo_data["anomalies"]
    ).dict()

@app.post("/savings/plan")
async def create_savings_plan(request: SavingsRequest):
    """Create a personalized savings plan."""
    monthly_target = request.goal_amount / request.goal_months
    
    # Generate realistic action recommendations
    actions = [
        {
            "category": "Subscription Optimization",
            "description": "Cancel unused Netflix subscription and switch to a family plan for Spotify",
            "monthly_savings": 500,
            "pain_score": 2
        },
        {
            "category": "Dining & Food",
            "description": "Reduce restaurant visits by 30% and cook more meals at home",
            "monthly_savings": 2000,
            "pain_score": 5
        },
        {
            "category": "Entertainment",
            "description": "Find free or low-cost entertainment alternatives",
            "monthly_savings": 1000,
            "pain_score": 4
        },
        {
            "category": "Transportation",
            "description": "Use public transport twice a week instead of rideshare",
            "monthly_savings": 800,
            "pain_score": 3
        },
        {
            "category": "Shopping",
            "description": "Set monthly shopping budget limits and stick to shopping lists",
            "monthly_savings": 1500,
            "pain_score": 6
        }
    ]
    
    # Select actions that roughly meet the target
    selected_actions = []
    total_savings = 0
    
    for action in sorted(actions, key=lambda x: x["pain_score"]):
        if total_savings < monthly_target:
            selected_actions.append(action)
            total_savings += action["monthly_savings"]
    
    return SavingsPlanResponse(
        goal_amount=request.goal_amount,
        goal_months=request.goal_months,
        monthly_target=monthly_target,
        recommended_actions=selected_actions
    ).dict()

@app.get("/insights/subscriptions")
async def get_subscriptions():
    """Get detected subscription services."""
    return {"subscriptions": demo_data["subscriptions"]}

@app.get("/insights/anomalies")
async def get_anomalies():
    """Get detected spending anomalies."""
    return {"anomalies": demo_data["anomalies"]}

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Finance AI Demo API Server...")
    print("📊 Serving realistic financial demo data")
    print("🌐 Frontend can connect to: http://localhost:8000")
    print("📖 API docs available at: http://localhost:8000/docs")
    print("=" * 50)
    
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        reload=False,
        log_level="info"
    )
