from datetime import datetime, timedelta
from jose import jwt
from argon2 import PasswordHasher
import os

SECRET = os.getenv("JWT_SECRET", "supersecretjwt")
ALGORITHM = "HS256"
EXPIRES_MIN = int(os.getenv("JWT_EXPIRES_MIN", "1440"))

# Initialize Argon2 password hasher
ph = PasswordHasher()


def hash_password(password: str) -> str:
    """Hash password using Argon2"""
    return ph.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    """Verify password against Argon2 hash"""
    try:
        ph.verify(hashed, password)
        return True
    except Exception:
        return False


def create_access_token(subject: str) -> str:
    """Create JWT access token"""
    expire = datetime.utcnow() + timedelta(minutes=EXPIRES_MIN)
    payload = {
        "sub": subject,
        "exp": expire,
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET, algorithm=ALGORITHM)
