from pymongo import MongoClient
from pymongo.database import Database
from ..config import get_settings

settings = get_settings()


class MongoDB:
    """MongoDB connection manager"""
    
    def __init__(self):
        # Always connect to configured MongoDB; rely on Docker compose for service
        self.client = MongoClient(settings.MONGO_URI)
        self.db = self.client[settings.MONGO_DB]
    
    def get_database(self) -> Database:
        return self.db
    
    def close(self):
        self.client.close()


# Global MongoDB instance
mongodb = MongoDB()


def get_mongo_db() -> Database:
    """Dependency to get MongoDB database"""
    return mongodb.get_database()
