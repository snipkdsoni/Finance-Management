import os
from functools import lru_cache
from dotenv import load_dotenv

load_dotenv()


class Settings:
    """Application settings loaded from environment variables"""
    
    # Environment
    ENV = os.getenv("ENV", "dev")
    
    # JWT Configuration
    JWT_SECRET = os.getenv("JWT_SECRET", "supersecretjwt")
    JWT_EXPIRES_MIN = int(os.getenv("JWT_EXPIRES_MIN", "1440"))
    
    # PostgreSQL Configuration
    POSTGRES_USER = os.getenv("POSTGRES_USER", "fin")
    POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "finpass")
    POSTGRES_DB = os.getenv("POSTGRES_DB", "fin_db")
    POSTGRES_HOST = os.getenv("POSTGRES_HOST", "localhost")
    POSTGRES_PORT = int(os.getenv("POSTGRES_PORT", "5432"))
    
    # MongoDB Configuration
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    MONGO_DB = os.getenv("MONGO_DB", "fin_optimizer")
    
    @property
    def postgres_url(self) -> str:
        # Always use Postgres when variables are set; SQLite fallback only if explicitly unset
        if self.POSTGRES_HOST and self.POSTGRES_USER and self.POSTGRES_DB:
            return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        return "sqlite:///./finance.db"


@lru_cache()
def get_settings() -> Settings:
    """Get cached application settings"""
    return Settings()
