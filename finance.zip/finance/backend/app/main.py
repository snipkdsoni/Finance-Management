from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .auth.routes import router as auth_router
from .finance.routes import router as fin_router

# Import models to ensure they're registered with SQLAlchemy
from .auth import models as auth_models
from .finance import models_sql as finance_models

app = FastAPI(
    title="AI Finance Optimizer",
    version="1.0.0",
    description="AI-Powered Personal Finance Optimizer with transaction analysis and budget planning"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    """Health check endpoint"""
    return {"status": "ok", "message": "Finance Optimizer API is running"}


app.include_router(auth_router, prefix="/auth", tags=["Authentication"])
app.include_router(fin_router, prefix="/finance", tags=["Finance"])


@app.on_event("startup")
async def startup_event():
    """Create database tables on startup"""
    from .db.sql import create_tables
    create_tables()
    print("Database tables created successfully!")
