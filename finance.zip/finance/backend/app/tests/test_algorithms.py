import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from decimal import Decimal

from app.finance.subscriptions import detect_subscriptions, autocorrelation_analysis
from app.finance.anomalies import detect_anomalies, robust_zscore
from app.finance.optimizer import BudgetOptimizer, OptimizationAction
from app.finance.classifiers import TransactionClassifier


class TestSubscriptionDetection:
    """Test subscription detection algorithms"""
    
    def test_monthly_subscription_detection(self):
        """Test detection of monthly recurring transactions"""
        # Create synthetic monthly subscription data
        dates = []
        base_date = datetime(2024, 1, 15)
        for i in range(6):  # 6 months
            dates.append(base_date + timedelta(days=i * 30))
        
        df = pd.DataFrame({
            'date': dates,
            'merchant': ['Netflix'] * 6,
            'amount': [799.0] * 6  # Consistent monthly amount
        })
        
        subscriptions = detect_subscriptions(df)
        
        assert 'Netflix' in subscriptions
        assert subscriptions['Netflix']['cadence_type'] == 'monthly'
        assert 28 <= subscriptions['Netflix']['cadence_days'] <= 31
        assert subscriptions['Netflix']['confidence'] > 0.6
    
    def test_weekly_subscription_detection(self):
        """Test detection of weekly recurring transactions"""
        dates = []
        base_date = datetime(2024, 1, 1)
        for i in range(8):  # 8 weeks
            dates.append(base_date + timedelta(days=i * 7))
        
        df = pd.DataFrame({
            'date': dates,
            'merchant': ['Weekly Service'] * 8,
            'amount': [200.0] * 8
        })
        
        subscriptions = detect_subscriptions(df)
        
        assert 'Weekly Service' in subscriptions
        assert subscriptions['Weekly Service']['cadence_type'] == 'weekly'
        assert 6 <= subscriptions['Weekly Service']['cadence_days'] <= 8
    
    def test_no_false_positives(self):
        """Test that irregular transactions are not marked as subscriptions"""
        # Random irregular transactions
        dates = [
            datetime(2024, 1, 5),
            datetime(2024, 1, 12),
            datetime(2024, 2, 8),
            datetime(2024, 3, 20),
        ]
        
        df = pd.DataFrame({
            'date': dates,
            'merchant': ['Random Store'] * 4,
            'amount': [150.0, 200.0, 180.0, 300.0]
        })
        
        subscriptions = detect_subscriptions(df)
        
        # Should not detect any subscriptions due to irregular pattern
        assert len(subscriptions) == 0
    
    def test_autocorrelation_analysis(self):
        """Test autocorrelation calculation for periodicity"""
        # Perfect periodic pattern
        periodic_gaps = np.array([30, 30, 30, 30, 30])
        autocorr = autocorrelation_analysis(periodic_gaps)
        
        # Should have high autocorrelation for regular pattern
        assert autocorr > 0.5
        
        # Random pattern
        random_gaps = np.array([15, 45, 8, 62, 23])
        autocorr_random = autocorrelation_analysis(random_gaps)
        
        # Should have low autocorrelation for random pattern
        assert autocorr_random < autocorr


class TestAnomalyDetection:
    """Test anomaly detection algorithms"""
    
    def test_robust_zscore_calculation(self):
        """Test robust z-score calculation"""
        # Data with clear outlier
        data = np.array([100, 102, 98, 101, 99, 103, 500])  # 500 is outlier
        
        z_scores = robust_zscore(data)
        
        # Outlier should have high z-score
        assert abs(z_scores[-1]) > 3.0
        # Normal values should have low z-scores
        assert all(abs(z) < 2.0 for z in z_scores[:-1])
    
    def test_anomaly_detection_integration(self):
        """Test end-to-end anomaly detection"""
        # Create data with known anomaly
        df = pd.DataFrame({
            'merchant': ['Store A'] * 5 + ['Store B'] * 5,
            'amount': [100, 102, 98, 101, 1000] + [200, 205, 195, 198, 202],  # 1000 is anomaly
            'date': [datetime(2024, 1, i+1) for i in range(10)]
        })
        
        anomalies = detect_anomalies(df, group_cols=('merchant',))
        
        # Should detect the 1000 amount as anomaly
        assert len(anomalies) >= 1
        
        # Find the anomaly for Store A
        store_a_anomalies = [a for a in anomalies.values() if a['group_key'] == 'Store A']
        assert len(store_a_anomalies) > 0
        assert any(a['actual_amount'] == 1000 for a in store_a_anomalies)
    
    def test_no_false_anomalies(self):
        """Test that normal transactions are not flagged as anomalies"""
        # Consistent spending pattern
        df = pd.DataFrame({
            'merchant': ['Regular Store'] * 10,
            'amount': np.random.normal(100, 5, 10),  # Normal distribution around 100
            'date': [datetime(2024, 1, i+1) for i in range(10)]
        })
        
        anomalies = detect_anomalies(df, group_cols=('merchant',), min_transactions=5)
        
        # Should detect no anomalies in normal distribution
        assert len(anomalies) == 0


class TestBudgetOptimizer:
    """Test budget optimization algorithms"""
    
    def test_optimization_action_efficiency(self):
        """Test efficiency calculation for optimization actions"""
        action = OptimizationAction(
            action_type="cancel",
            target="Netflix",
            description="Cancel subscription",
            save_amount=799.0,
            pain_score=0.2
        )
        
        # Efficiency should be save_amount / pain_score
        expected_efficiency = 799.0 / (0.2 + 0.01)
        assert abs(action.efficiency - expected_efficiency) < 1.0
    
    def test_greedy_optimization(self):
        """Test greedy optimization algorithm"""
        optimizer = BudgetOptimizer()
        
        # Create test actions
        actions = [
            OptimizationAction("cancel", "Netflix", "Cancel Netflix", 799.0, 0.2),
            OptimizationAction("cancel", "Spotify", "Cancel Spotify", 119.0, 0.1),
            OptimizationAction("reduce", "Dining", "Reduce dining", 2000.0, 0.7),
        ]
        
        # Test greedy selection
        selected, total_savings = optimizer._greedy_selection(actions, 1000.0, 1.0)
        
        # Should select actions that fit within pain budget
        assert total_savings >= 1000.0  # Should meet savings goal
        assert sum(a.pain_score for a in selected) <= 1.0  # Should respect pain limit
    
    def test_knapsack_optimization(self):
        """Test knapsack optimization algorithm"""
        optimizer = BudgetOptimizer()
        
        actions = [
            OptimizationAction("cancel", "Service A", "Cancel A", 500.0, 0.3),
            OptimizationAction("cancel", "Service B", "Cancel B", 400.0, 0.2),
            OptimizationAction("reduce", "Category C", "Reduce C", 600.0, 0.4),
        ]
        
        selected, total_savings = optimizer.optimize_with_knapsack(actions, 800.0, 0.6)
        
        # Should find optimal combination within constraints
        assert total_savings >= 800.0 or len(selected) > 0
        assert sum(a.pain_score for a in selected) <= 0.6
    
    def test_plan_generation(self):
        """Test complete plan generation"""
        optimizer = BudgetOptimizer()
        
        # Mock data
        df = pd.DataFrame({
            'merchant': ['Netflix', 'Swiggy', 'Amazon'],
            'amount': [799, 1500, 2000],
            'date': [datetime(2024, 1, 1)] * 3,
            'predicted_category': ['Entertainment', 'Food & Dining', 'Shopping']
        })
        
        subscriptions = {'Netflix': {'avg_amount': 799, 'cadence_type': 'monthly'}}
        anomalies = {}
        
        plan = optimizer.generate_plan(df, subscriptions, anomalies, 1000.0)
        
        assert 'savings_goal' in plan
        assert 'projected_savings' in plan
        assert 'actions' in plan
        assert plan['savings_goal'] == 1000.0
        assert isinstance(plan['actions'], list)


class TestTransactionClassifier:
    """Test transaction classification algorithms"""
    
    def test_rule_based_classification(self):
        """Test rule-based transaction classification"""
        classifier = TransactionClassifier()
        
        # Test known patterns
        category, confidence = classifier.predict("Swiggy", "Food delivery")
        assert category == "Food & Dining"
        assert confidence > 0.8  # High confidence for rule-based match
        
        category, confidence = classifier.predict("Netflix", "Monthly subscription")
        assert category == "Entertainment"
        assert confidence > 0.8
    
    def test_batch_classification(self):
        """Test batch classification of transactions"""
        classifier = TransactionClassifier()
        
        df = pd.DataFrame({
            'merchant': ['Swiggy', 'BigBasket', 'Uber', 'Unknown Merchant'],
            'raw_description': ['Food order', 'Grocery delivery', 'Cab ride', 'Random purchase']
        })
        
        result_df = classifier.predict_batch(df)
        
        assert 'predicted_category' in result_df.columns
        assert 'prediction_confidence' in result_df.columns
        assert len(result_df) == 4
        
        # Known merchants should be classified correctly
        swiggy_row = result_df[result_df['merchant'] == 'Swiggy'].iloc[0]
        assert swiggy_row['predicted_category'] == 'Food & Dining'
    
    def test_unknown_merchant_classification(self):
        """Test classification of unknown merchants"""
        classifier = TransactionClassifier()
        
        category, confidence = classifier.predict("Unknown Store XYZ", "Some purchase")
        
        # Should default to Miscellaneous for unknown merchants
        assert category == "Miscellaneous"
        assert confidence == 0.1  # Low confidence


class TestIntegration:
    """Integration tests combining multiple algorithms"""
    
    def test_full_analysis_pipeline(self):
        """Test complete analysis pipeline with all algorithms"""
        # Create comprehensive test dataset
        df = pd.DataFrame({
            'date': [datetime(2024, 1, 1) + timedelta(days=i*30) for i in range(6)] + 
                   [datetime(2024, 1, 15), datetime(2024, 2, 12)],
            'merchant': ['Netflix'] * 6 + ['Store A', 'Store A'],
            'amount': [799] * 6 + [100, 5000],  # Regular Netflix + normal and anomalous Store A
            'raw_description': ['Subscription'] * 6 + ['Purchase', 'Expensive purchase']
        })
        
        # Run all algorithms
        subscriptions = detect_subscriptions(df)
        anomalies = detect_anomalies(df)
        classifier = TransactionClassifier()
        df_classified = classifier.predict_batch(df)
        
        # Verify results
        assert 'Netflix' in subscriptions  # Should detect Netflix subscription
        assert len(anomalies) > 0  # Should detect 5000 amount as anomaly
        assert 'predicted_category' in df_classified.columns
        
        # Netflix should be classified as Entertainment
        netflix_rows = df_classified[df_classified['merchant'] == 'Netflix']
        assert all(netflix_rows['predicted_category'] == 'Entertainment')


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
