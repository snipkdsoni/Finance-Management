import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import tempfile
import os

from app.main import app
from app.db.sql import Base, get_db
from app.auth.models import User

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create test tables
Base.metadata.create_all(bind=engine)


def override_get_db():
    """Override database dependency for testing"""
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)


@pytest.fixture(scope="function")
def test_user():
    """Create a test user and return auth token"""
    # Register test user
    response = client.post(
        "/auth/register",
        json={
            "email": "test@example.com",
            "password": "testpass123",
            "full_name": "Test User"
        }
    )
    assert response.status_code == 200
    return response.json()


class TestAuth:
    """Test authentication endpoints"""
    
    def test_register_user(self):
        """Test user registration"""
        response = client.post(
            "/auth/register",
            json={
                "email": "newuser@test.com",
                "password": "password123",
                "full_name": "New User"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["email"] == "newuser@test.com"
        assert data["token_type"] == "bearer"
    
    def test_register_duplicate_email(self):
        """Test registration with duplicate email fails"""
        # Register first user
        client.post(
            "/auth/register",
            json={"email": "duplicate@test.com", "password": "pass123"}
        )
        
        # Try to register with same email
        response = client.post(
            "/auth/register",
            json={"email": "duplicate@test.com", "password": "pass456"}
        )
        
        assert response.status_code == 400
        assert "already registered" in response.json()["detail"].lower()
    
    def test_login_success(self):
        """Test successful login"""
        # Register user first
        client.post(
            "/auth/register",
            json={"email": "login@test.com", "password": "loginpass"}
        )
        
        # Login
        response = client.post(
            "/auth/login",
            json={"email": "login@test.com", "password": "loginpass"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["email"] == "login@test.com"
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials"""
        response = client.post(
            "/auth/login",
            json={"email": "notexist@test.com", "password": "wrongpass"}
        )
        
        assert response.status_code == 401
        assert "incorrect" in response.json()["detail"].lower()


class TestProtectedEndpoints:
    """Test protected finance endpoints"""
    
    def test_protected_endpoint_without_auth(self):
        """Test that protected endpoints require authentication"""
        response = client.get("/finance/insights")
        assert response.status_code == 401
    
    def test_insights_with_auth(self, test_user):
        """Test insights endpoint with authentication"""
        token = test_user["access_token"]
        
        response = client.get(
            "/finance/insights",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        # Should return 200 even with no data
        assert response.status_code == 200
        data = response.json()
        assert "total_spend" in data
        assert "subscriptions_count" in data
        assert "anomalies_count" in data
    
    def test_dashboard_endpoint(self, test_user):
        """Test dashboard endpoint"""
        token = test_user["access_token"]
        
        response = client.get(
            "/finance/dashboard",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "kpis" in data
        assert "category_breakdown" in data
        assert "monthly_trend" in data
    
    def test_subscriptions_endpoint(self, test_user):
        """Test subscriptions endpoint"""
        token = test_user["access_token"]
        
        response = client.get(
            "/finance/subscriptions",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_anomalies_endpoint(self, test_user):
        """Test anomalies endpoint"""
        token = test_user["access_token"]
        
        response = client.get(
            "/finance/anomalies",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_accounts_endpoint(self, test_user):
        """Test accounts management"""
        token = test_user["access_token"]
        
        # Get accounts (should be empty initially)
        response = client.get(
            "/finance/accounts",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        assert isinstance(response.json(), list)
        
        # Create account
        response = client.post(
            "/finance/accounts",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "name": "Test Account",
                "account_type": "savings",
                "currency": "INR"
            }
        )
        assert response.status_code == 200
        account_data = response.json()
        assert account_data["name"] == "Test Account"
        assert account_data["account_type"] == "savings"
    
    def test_create_plan(self, test_user):
        """Test optimization plan creation"""
        token = test_user["access_token"]
        
        response = client.post(
            "/finance/plan",
            headers={"Authorization": f"Bearer {token}"},
            json={"savings_goal": 5000}
        )
        
        # Should work even with no transaction data
        assert response.status_code == 200
        data = response.json()
        assert "savings_goal" in data
        assert "projected_savings" in data
        assert "actions" in data
    
    def test_what_if_analysis(self, test_user):
        """Test what-if analysis endpoint"""
        token = test_user["access_token"]
        
        response = client.post(
            "/finance/whatif",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "savings_goal": 3000,
                "caps": {"Food & Dining": 5000}
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "projected_savings" in data
        assert "goal_met" in data
        assert "actions" in data


class TestFileUpload:
    """Test file upload functionality"""
    
    def test_upload_without_file(self, test_user):
        """Test upload endpoint without file"""
        token = test_user["access_token"]
        
        response = client.post(
            "/finance/upload",
            headers={"Authorization": f"Bearer {token}"},
            data={"account_id": "1"}
        )
        
        assert response.status_code == 422  # Validation error
    
    def test_upload_csv_file(self, test_user):
        """Test CSV file upload"""
        token = test_user["access_token"]
        
        # Create test account first
        account_response = client.post(
            "/finance/accounts",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "Upload Test", "account_type": "savings"}
        )
        account_id = account_response.json()["id"]
        
        # Create test CSV content
        csv_content = """date,amount,merchant,description
2024-01-01,100.00,Test Store,Purchase
2024-01-02,50.00,Coffee Shop,Coffee
"""
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as tmp_file:
            tmp_file.write(csv_content)
            tmp_file_path = tmp_file.name
        
        try:
            # Upload file
            with open(tmp_file_path, 'rb') as f:
                response = client.post(
                    "/finance/upload",
                    headers={"Authorization": f"Bearer {token}"},
                    files={"file": ("test.csv", f, "text/csv")},
                    data={"account_id": str(account_id)}
                )
            
            assert response.status_code == 200
            data = response.json()
            assert "imported" in data
            assert data["imported"] >= 0
            
        finally:
            # Cleanup
            os.unlink(tmp_file_path)


class TestHealthCheck:
    """Test health and utility endpoints"""
    
    def test_health_endpoint(self):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
    
    def test_api_docs_accessible(self):
        """Test that API documentation is accessible"""
        response = client.get("/docs")
        assert response.status_code == 200
        
        response = client.get("/openapi.json")
        assert response.status_code == 200


class TestErrorHandling:
    """Test error handling and edge cases"""
    
    def test_invalid_json(self):
        """Test API response to invalid JSON"""
        response = client.post(
            "/auth/login",
            data="invalid json",
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 422
    
    def test_missing_required_fields(self):
        """Test API response to missing required fields"""
        response = client.post("/auth/register", json={})
        assert response.status_code == 422
    
    def test_invalid_token_format(self):
        """Test API response to invalid token format"""
        response = client.get(
            "/finance/insights",
            headers={"Authorization": "Bearer invalid_token_format"}
        )
        assert response.status_code == 401


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
