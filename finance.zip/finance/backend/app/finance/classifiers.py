import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from collections import defaultdict
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class TransactionClassifier:
    """
    Hybrid transaction classifier using rule-based heuristics + TF-IDF similarity.
    
    Combines:
    1. Rule-based classification for common merchant patterns
    2. TF-IDF vectorization for semantic similarity
    3. Learning from existing labeled transactions
    """
    
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            max_features=1000,
            ngram_range=(1, 2),
            stop_words='english',
            lowercase=True
        )
        self.category_vectors = {}
        self.rule_patterns = self._build_rule_patterns()
        self.is_trained = False
    
    def _build_rule_patterns(self) -> Dict[str, List[str]]:
        """Define rule-based patterns for common merchant categories"""
        return {
            "Food & Dining": [
                r"swiggy", r"zomato", r"foodpanda", r"dominos", r"pizza", r"restaurant",
                r"cafe", r"starbucks", r"mcdonalds", r"kfc", r"subway", r"dine", r"food"
            ],
            "Groceries": [
                r"bigbasket", r"grofers", r"blinkit", r"dunzo", r"supermarket", r"grocery",
                r"fresh", r"mart", r"store", r"provisions"
            ],
            "Transport": [
                r"uber", r"ola", r"rapido", r"metro", r"bus", r"taxi", r"auto", r"petrol",
                r"fuel", r"parking", r"toll", r"transport"
            ],
            "Entertainment": [
                r"netflix", r"amazon prime", r"hotstar", r"spotify", r"youtube", r"movie",
                r"cinema", r"pvr", r"inox", r"bookmyshow", r"entertainment", r"gaming"
            ],
            "Utilities": [
                r"electricity", r"water", r"gas", r"internet", r"broadband", r"wifi",
                r"mobile", r"phone", r"recharge", r"bill", r"utility"
            ],
            "Shopping": [
                r"amazon", r"flipkart", r"myntra", r"ajio", r"shopping", r"mall",
                r"store", r"retail", r"fashion", r"clothing", r"electronics"
            ],
            "Health": [
                r"hospital", r"clinic", r"doctor", r"medical", r"pharmacy", r"medicine",
                r"health", r"fitness", r"gym", r"wellness"
            ],
            "Education": [
                r"school", r"college", r"university", r"course", r"training", r"education",
                r"tuition", r"books", r"learning", r"study"
            ],
            "Subscriptions": [
                r"subscription", r"monthly", r"annual", r"premium", r"pro", r"plus",
                r"membership", r"plan"
            ]
        }
    
    def _apply_rules(self, text: str) -> Optional[str]:
        """Apply rule-based classification"""
        text_lower = text.lower()
        
        for category, patterns in self.rule_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_lower):
                    return category
        
        return None
    
    def _preprocess_text(self, text: str) -> str:
        """Clean and preprocess text for TF-IDF"""
        if not text:
            return ""
        
        # Remove special characters, keep alphanumeric and spaces
        text = re.sub(r'[^a-zA-Z0-9\s]', ' ', str(text))
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text.lower()
    
    def train(self, transactions_df: pd.DataFrame, merchant_col: str = "merchant", 
              category_col: str = "category", description_col: str = "raw_description"):
        """Train the classifier on labeled transactions"""
        
        # Filter transactions that have category labels
        labeled_df = transactions_df[transactions_df[category_col].notna()].copy()
        
        if len(labeled_df) == 0:
            print("No labeled transactions found for training")
            return
        
        # Combine merchant and description for richer features
        labeled_df["combined_text"] = (
            labeled_df[merchant_col].fillna("") + " " + 
            labeled_df[description_col].fillna("")
        ).apply(self._preprocess_text)
        
        # Group by category and create category profiles
        category_texts = defaultdict(list)
        for _, row in labeled_df.iterrows():
            category_texts[row[category_col]].append(row["combined_text"])
        
        # Create TF-IDF vectors for each category
        all_texts = []
        category_labels = []
        
        for category, texts in category_texts.items():
            # Combine all texts for this category
            combined_category_text = " ".join(texts)
            all_texts.append(combined_category_text)
            category_labels.append(category)
        
        if len(all_texts) > 0:
            # Fit TF-IDF vectorizer
            self.vectorizer.fit(all_texts)
            
            # Create category vectors
            category_matrix = self.vectorizer.transform(all_texts)
            
            for i, category in enumerate(category_labels):
                self.category_vectors[category] = category_matrix[i]
            
            self.is_trained = True
            print(f"Trained classifier on {len(labeled_df)} transactions across {len(category_labels)} categories")
    
    def predict(self, merchant: str, description: str = "", confidence_threshold: float = 0.3) -> Tuple[Optional[str], float]:
        """
        Predict category for a transaction using hybrid approach.
        
        Returns:
            Tuple of (predicted_category, confidence_score)
        """
        combined_text = f"{merchant} {description}"
        
        # First, try rule-based classification
        rule_prediction = self._apply_rules(combined_text)
        if rule_prediction:
            return rule_prediction, 0.9  # High confidence for rule-based matches
        
        # If no rule match and TF-IDF is trained, use semantic similarity
        if self.is_trained and self.category_vectors:
            processed_text = self._preprocess_text(combined_text)
            
            try:
                # Vectorize the input text
                input_vector = self.vectorizer.transform([processed_text])
                
                # Calculate similarity with each category
                best_category = None
                best_score = 0.0
                
                for category, category_vector in self.category_vectors.items():
                    similarity = cosine_similarity(input_vector, category_vector)[0][0]
                    if similarity > best_score:
                        best_score = similarity
                        best_category = category
                
                # Return prediction if confidence is above threshold
                if best_score >= confidence_threshold:
                    return best_category, float(best_score)
                    
            except Exception as e:
                print(f"TF-IDF prediction error: {e}")
        
        # Default to "Miscellaneous" if no confident prediction
        return "Miscellaneous", 0.1
    
    def predict_batch(self, transactions_df: pd.DataFrame, 
                     merchant_col: str = "merchant", 
                     description_col: str = "raw_description") -> pd.DataFrame:
        """Predict categories for a batch of transactions"""
        df_result = transactions_df.copy()
        df_result["predicted_category"] = None
        df_result["prediction_confidence"] = 0.0
        
        for idx, row in df_result.iterrows():
            merchant = str(row.get(merchant_col, ""))
            description = str(row.get(description_col, ""))
            
            category, confidence = self.predict(merchant, description)
            df_result.loc[idx, "predicted_category"] = category
            df_result.loc[idx, "prediction_confidence"] = confidence
        
        return df_result
    
    def get_category_stats(self) -> Dict[str, int]:
        """Get statistics about trained categories"""
        if not self.is_trained:
            return {}
        
        return {category: 1 for category in self.category_vectors.keys()}


def create_default_categories() -> List[Dict[str, any]]:
    """Create default category structure for the application"""
    categories = [
        {"name": "Food & Dining", "color": "#FF6B6B", "icon": "🍽️"},
        {"name": "Groceries", "color": "#4ECDC4", "icon": "🛒"},
        {"name": "Transport", "color": "#45B7D1", "icon": "🚗"},
        {"name": "Entertainment", "color": "#96CEB4", "icon": "🎬"},
        {"name": "Utilities", "color": "#FFEAA7", "icon": "💡"},
        {"name": "Shopping", "color": "#DDA0DD", "icon": "🛍️"},
        {"name": "Health", "color": "#FF7675", "icon": "🏥"},
        {"name": "Education", "color": "#74B9FF", "icon": "📚"},
        {"name": "Subscriptions", "color": "#A29BFE", "icon": "📱"},
        {"name": "Miscellaneous", "color": "#636E72", "icon": "❓"}
    ]
    return categories


def enhanced_merchant_clustering(transactions_df: pd.DataFrame, merchant_col: str = "merchant") -> Dict[str, List[str]]:
    """
    Group similar merchants using string similarity.
    Useful for handling variations like 'AMAZON.IN' vs 'Amazon India'
    """
    merchants = transactions_df[merchant_col].dropna().unique()
    clusters = defaultdict(list)
    
    for merchant in merchants:
        # Simple clustering based on common prefixes/suffixes
        normalized = re.sub(r'[^a-zA-Z0-9]', '', merchant.lower())
        
        # Find cluster key (first 4-6 characters)
        key = normalized[:6] if len(normalized) >= 6 else normalized
        clusters[key].append(merchant)
    
    # Filter clusters with multiple merchants
    return {k: v for k, v in clusters.items() if len(v) > 1}
