from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session
from pymongo.database import Database
from typing import List, Optional

from ..deps import get_current_user
from ..db.sql import get_db
from ..db.mongo import get_mongo_db
from ..auth.models import User
from .services import FinanceService
from .schemas import (
    UploadResponse, InsightsResponse, SubscriptionResponse, AnomalyResponse,
    PlanRequest, PlanResponse, WhatIfRequest, WhatIfResponse,
    AccountCreate, AccountResponse, TransactionResponse
)

router = APIRouter()


def get_finance_service(
    db: Session = Depends(get_db),
    mongo_db: Database = Depends(get_mongo_db)
) -> FinanceService:
    """Dependency to get finance service instance"""
    return FinanceService(db, mongo_db)


@router.post("/upload", response_model=UploadResponse)
async def upload_transactions(
    file: UploadFile = File(...),
    account_id: int = Form(...),
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Upload transaction file (CSV or Excel) for processing.
    
    Supports flexible column mapping and data validation.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")
    
    # Read file content
    file_content = await file.read()
    
    # Process file
    result = finance_service.upload_transactions(
        user_id=current_user.id,
        file_content=file_content,
        filename=file.filename,
        account_id=account_id
    )
    
    if not result.get("success", False):
        raise HTTPException(
            status_code=400,
            detail=result.get("error", "Failed to process file")
        )
    
    return UploadResponse(
        imported=result["imported"],
        skipped=result.get("skipped", 0),
        errors=result.get("errors", [])
    )


@router.post("/seed")
async def seed_demo_data(
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Generate demo data for development/testing.
    
    Creates 6 months of realistic transaction data.
    """
    # Only allow for specific demo user or in dev environment
    if current_user.email != "demo@fin.com":
        raise HTTPException(status_code=403, detail="Demo seeding only allowed for demo user")
    
    from .ingestion import SeedDataGenerator
    generator = SeedDataGenerator()
    
    try:
        result = generator.create_demo_user_and_data()
        return {"message": result["message"], "transactions_count": result.get("transactions_count", 0)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate demo data: {str(e)}")


@router.get("/insights", response_model=InsightsResponse)
async def get_insights(
    window_days: int = 30,
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Get comprehensive financial insights and KPIs.
    
    Includes spending analysis, trends, and optimization potential.
    """
    insights = finance_service.get_user_insights(current_user.id, window_days)
    
    return InsightsResponse(
        total_spend=insights["total_spend"],
        subscriptions_count=insights["subscriptions_count"],
        anomalies_count=insights["anomalies_count"],
        projected_savings=insights["projected_savings"],
        category_breakdown=insights["category_breakdown"],
        monthly_trend=insights["monthly_trend"]
    )


@router.get("/subscriptions", response_model=List[SubscriptionResponse])
async def get_subscriptions(
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Get detected recurring subscriptions with analysis.
    
    Uses periodicity detection and pattern analysis.
    """
    subscriptions = finance_service.get_subscription_analysis(current_user.id)
    
    return [
        SubscriptionResponse(
            merchant=sub["merchant"],
            avg_amount=sub["avg_amount"],
            cadence_days=sub["cadence_days"],
            last_transaction=sub["last_transaction"],
            total_transactions=sub["total_transactions"],
            confidence=sub["confidence"]
        )
        for sub in subscriptions
    ]


@router.get("/anomalies", response_model=List[AnomalyResponse])
async def get_anomalies(
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Get detected spending anomalies with explanations.
    
    Uses robust z-score analysis to identify outliers.
    """
    anomalies = finance_service.get_anomaly_analysis(current_user.id)
    
    return [
        AnomalyResponse(
            transaction_id=anom["transaction_id"],
            date=anom["date"],
            merchant=anom["merchant"],
            amount=anom["amount"],
            expected_range=anom["expected_range"],
            anomaly_score=anom["anomaly_score"],
            reason=anom["reason"]
        )
        for anom in anomalies
    ]


@router.post("/plan")
async def create_optimization_plan(
    plan_request: PlanRequest,
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Create monthly optimization plan to meet savings goal.
    
    Uses knapsack-style algorithm to minimize pain while maximizing savings.
    """
    plan = finance_service.create_optimization_plan(
        user_id=current_user.id,
        savings_goal=float(plan_request.savings_goal),
        category_caps=plan_request.caps
    )
    
    if "error" in plan:
        raise HTTPException(status_code=400, detail=plan["error"])
    
    return {
        "id": plan["id"],
        "month": plan["target_month"],
        "savings_goal": plan["savings_goal"],
        "projected_savings": plan["projected_savings"],
        "goal_met": plan["goal_met"],
        "actions": plan["actions"],
        "insights": plan.get("insights", {}),
        "created_at": plan["created_at"]
    }


@router.post("/whatif", response_model=WhatIfResponse)
async def what_if_analysis(
    whatif_request: WhatIfRequest,
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Perform what-if scenario analysis.
    
    Test different savings goals and constraints.
    """
    results = finance_service.what_if_analysis(
        user_id=current_user.id,
        savings_goal=float(whatif_request.savings_goal),
        category_caps=whatif_request.caps
    )
    
    if "error" in results:
        raise HTTPException(status_code=400, detail=results["error"])
    
    return WhatIfResponse(
        projected_savings=results["results"]["projected_savings"],
        goal_met=results["results"]["goal_met"],
        actions=results["results"]["actions"],
        impact_summary=results["impact_summary"]
    )


@router.get("/accounts", response_model=List[AccountResponse])
async def get_accounts(
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """Get user's financial accounts"""
    accounts = finance_service.get_user_accounts(current_user.id)
    
    return [
        AccountResponse(
            id=acc["id"],
            user_id=current_user.id,
            name=acc["name"],
            account_type=acc["account_type"],
            currency=acc["currency"]
        )
        for acc in accounts
    ]


@router.post("/accounts", response_model=AccountResponse)
async def create_account(
    account_data: AccountCreate,
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """Create a new financial account"""
    account = finance_service.create_user_account(
        user_id=current_user.id,
        name=account_data.name,
        account_type=account_data.account_type,
        currency=account_data.currency
    )
    
    return AccountResponse(
        id=account["id"],
        user_id=current_user.id,
        name=account["name"],
        account_type=account["account_type"],
        currency=account["currency"]
    )


@router.get("/transactions")
async def get_transactions(
    limit: int = 100,
    offset: int = 0,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's recent transactions"""
    from .models_sql import Transaction
    
    transactions = db.query(Transaction).filter(
        Transaction.user_id == current_user.id
    ).order_by(Transaction.date.desc()).offset(offset).limit(limit).all()
    
    return [
        {
            "id": txn.id,
            "date": txn.date.isoformat(),
            "amount": float(txn.amount),
            "merchant": txn.merchant,
            "raw_description": txn.raw_description,
            "currency": txn.currency,
            "is_subscription": txn.is_subscription,
            "is_anomaly": txn.is_anomaly,
            "account_id": txn.account_id
        }
        for txn in transactions
    ]


@router.get("/categories")
async def get_categories(db: Session = Depends(get_db)):
    """Get available transaction categories"""
    from .models_sql import Category
    
    categories = db.query(Category).all()
    
    return [
        {
            "id": cat.id,
            "name": cat.name,
            "color": cat.color,
            "icon": cat.icon,
            "parent_id": cat.parent_id
        }
        for cat in categories
    ]


@router.get("/dashboard")
async def get_dashboard_data(
    current_user: User = Depends(get_current_user),
    finance_service: FinanceService = Depends(get_finance_service)
):
    """
    Get comprehensive dashboard data in single request.
    
    Optimized endpoint that returns all data needed for dashboard.
    """
    # Get insights (uses caching)
    insights = finance_service.get_user_insights(current_user.id, window_days=30)
    
    # Get top subscriptions (limit to 5)
    subscriptions = finance_service.get_subscription_analysis(current_user.id)[:5]
    
    # Get top anomalies (limit to 5)
    anomalies = finance_service.get_anomaly_analysis(current_user.id)[:5]
    
    # Get accounts
    accounts = finance_service.get_user_accounts(current_user.id)
    
    return {
        "kpis": {
            "total_spend": insights["total_spend"],
            "subscriptions_count": insights["subscriptions_count"],
            "anomalies_count": insights["anomalies_count"],
            "projected_savings": insights["projected_savings"],
            "transaction_count": insights["transaction_count"]
        },
        "category_breakdown": insights["category_breakdown"],
        "monthly_trend": insights["monthly_trend"],
        "top_subscriptions": subscriptions,
        "recent_anomalies": anomalies,
        "accounts": accounts,
        "analysis_period": insights.get("analysis_period", {})
    }


@router.delete("/cache")
async def clear_cache(
    current_user: User = Depends(get_current_user),
    mongo_db: Database = Depends(get_mongo_db)
):
    """Clear cached insights for the current user"""
    from .models_mongo import MongoInsights
    
    mongo_insights = MongoInsights(mongo_db)
    mongo_insights.clear_user_cache(current_user.id)
    
    return {"message": "Cache cleared successfully"}
