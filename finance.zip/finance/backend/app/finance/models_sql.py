from sqlalchemy import Column, Integer, String, Numeric, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from ..db.sql import Base


class Account(Base):
    """Bank account model"""
    
    __tablename__ = "accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)  # "HDFC Savings", "SBI Credit"
    account_type = Column(String, nullable=False)  # "savings", "credit", "wallet"
    currency = Column(String, default="INR")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    transactions = relationship("Transaction", back_populates="account")


class Category(Base):
    """Transaction category model"""
    
    __tablename__ = "categories"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    parent_id = Column(Integer, ForeignKey("categories.id"))
    color = Column(String)  # for UI
    icon = Column(String)   # for UI
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Self-referential relationship for subcategories
    children = relationship("Category")
    transactions = relationship("Transaction", back_populates="category")


class Transaction(Base):
    """Financial transaction model"""
    
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    date = Column(DateTime(timezone=True), nullable=False)
    amount = Column(Numeric(precision=12, scale=2), nullable=False)
    currency = Column(String, default="INR")
    merchant = Column(String)
    raw_description = Column(Text)
    category_id = Column(Integer, ForeignKey("categories.id"))
    is_recurring = Column(Boolean, default=False)
    is_subscription = Column(Boolean, default=False)
    is_anomaly = Column(Boolean, default=False)
    anomaly_score = Column(Numeric(precision=5, scale=2))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    account = relationship("Account", back_populates="transactions")
    category = relationship("Category", back_populates="transactions")


class Budget(Base):
    """Monthly budget model"""
    
    __tablename__ = "budgets"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    month = Column(String, nullable=False)  # "2024-08"
    budgeted_amount = Column(Numeric(precision=12, scale=2), nullable=False)
    actual_amount = Column(Numeric(precision=12, scale=2), default=0)
    currency = Column(String, default="INR")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Plan(Base):
    """Monthly optimization plan model"""
    
    __tablename__ = "plans"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    month = Column(String, nullable=False)  # "2024-09"
    savings_goal = Column(Numeric(precision=12, scale=2), nullable=False)
    projected_savings = Column(Numeric(precision=12, scale=2), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    actions = relationship("PlanAction", back_populates="plan")


class PlanAction(Base):
    """Individual action within an optimization plan"""
    
    __tablename__ = "plan_actions"
    
    id = Column(Integer, primary_key=True, index=True)
    plan_id = Column(Integer, ForeignKey("plans.id"), nullable=False)
    action_type = Column(String, nullable=False)  # "cancel", "cap", "switch"
    target = Column(String, nullable=False)  # merchant name or category
    description = Column(Text)
    save_amount = Column(Numeric(precision=12, scale=2), nullable=False)
    pain_score = Column(Numeric(precision=3, scale=2))  # 0.0 to 1.0
    is_completed = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    plan = relationship("Plan", back_populates="actions")
