import numpy as np
import pandas as pd
from typing import Set, Dict, List, Tuple
from collections import defaultdict


def robust_zscore(x: np.ndarray, threshold: float = 3.5) -> np.ndarray:
    """
    Calculate robust z-scores using median and MAD (Median Absolute Deviation).
    
    Robust z-score = 0.6745 * (x - median) / MAD
    
    This is more resilient to outliers than standard z-score which uses mean/std.
    """
    median = np.median(x)
    mad = np.median(np.abs(x - median))
    
    # Add small epsilon to avoid division by zero
    mad = mad + 1e-9
    
    # Calculate robust z-scores
    z_scores = 0.6745 * (x - median) / mad
    return z_scores


def detect_anomalies(
    df: pd.DataFrame,
    amount_col: str = "amount",
    group_cols: Tuple[str, ...] = ("merchant",),
    threshold: float = 3.5,
    min_transactions: int = 5
) -> Dict[int, Dict]:
    """
    Detect transaction anomalies using robust z-score analysis.
    
    Algorithm:
    1. Group transactions by specified columns (merchant, category, etc.)
    2. For each group, calculate robust z-scores on log-transformed amounts
    3. Flag transactions with |z-score| > threshold as anomalies
    4. Return detailed anomaly information
    
    Args:
        df: DataFrame with transactions
        amount_col: Column name for transaction amounts
        group_cols: Columns to group by for anomaly detection
        threshold: Z-score threshold for anomaly detection
        min_transactions: Minimum transactions needed per group
        
    Returns:
        Dict mapping transaction indices to anomaly metadata
    """
    anomalies = {}
    df_work = df.copy()
    
    # Use absolute amounts and log-transform to handle skewed distributions
    df_work["log_amount"] = np.log1p(np.abs(df_work[amount_col]))
    
    # Group by specified columns and detect anomalies within each group
    for group_keys, group in df_work.groupby(list(group_cols)):
        if len(group) < min_transactions:
            continue
            
        # Calculate robust z-scores for this group
        amounts = group["log_amount"].values
        z_scores = robust_zscore(amounts, threshold)
        
        # Find anomalous transactions
        anomaly_mask = np.abs(z_scores) >= threshold
        anomaly_indices = group.index[anomaly_mask]
        
        for idx, z_score in zip(anomaly_indices, z_scores[anomaly_mask]):
            transaction = group.loc[idx]
            
            # Calculate expected range for this group
            group_amounts = np.abs(group[amount_col])
            q25, q75 = np.percentile(group_amounts, [25, 75])
            median_amount = np.median(group_amounts)
            
            # Determine anomaly type and reason
            actual_amount = abs(transaction[amount_col])
            anomaly_type = "high" if actual_amount > median_amount else "low"
            
            reason = f"Amount ₹{actual_amount:,.2f} is unusually {anomaly_type} for {group_keys[0] if isinstance(group_keys, tuple) else group_keys}"
            expected_range = f"₹{q25:,.2f} - ₹{q75:,.2f}"
            
            anomalies[idx] = {
                "transaction_id": int(transaction.get("id", idx)),
                "anomaly_score": round(abs(z_score), 2),
                "anomaly_type": anomaly_type,
                "reason": reason,
                "expected_range": expected_range,
                "actual_amount": float(actual_amount),
                "group_median": round(median_amount, 2),
                "group_mad": round(np.median(np.abs(group_amounts - median_amount)), 2),
                "group_size": len(group),
                "group_key": group_keys[0] if isinstance(group_keys, tuple) else group_keys
            }
    
    return anomalies


def detect_spending_spikes(
    df: pd.DataFrame,
    date_col: str = "date",
    amount_col: str = "amount",
    window_days: int = 7,
    spike_multiplier: float = 3.0
) -> Dict[str, Dict]:
    """
    Detect spending spikes - periods where spending is unusually high.
    
    Algorithm:
    1. Calculate rolling average spending over window_days
    2. Identify periods where current spending > spike_multiplier * rolling_avg
    3. Group consecutive spike days into events
    """
    df_sorted = df.sort_values(date_col)
    df_sorted["date"] = pd.to_datetime(df_sorted[date_col])
    
    # Group by date and calculate daily spending
    daily_spending = df_sorted.groupby(df_sorted["date"].dt.date)[amount_col].sum().abs()
    
    # Calculate rolling average
    rolling_avg = daily_spending.rolling(window=window_days, min_periods=1).mean()
    
    # Detect spikes
    spike_mask = daily_spending > (spike_multiplier * rolling_avg)
    spike_dates = daily_spending[spike_mask]
    
    spikes = {}
    for date, amount in spike_dates.items():
        expected = rolling_avg[date]
        spikes[str(date)] = {
            "date": str(date),
            "actual_spending": round(float(amount), 2),
            "expected_spending": round(float(expected), 2),
            "spike_ratio": round(float(amount / expected), 2),
            "excess_amount": round(float(amount - expected), 2)
        }
    
    return spikes


def multi_dimensional_anomaly_detection(
    df: pd.DataFrame,
    dimensions: List[Tuple[str, ...]] = [("merchant",), ("category",), ("merchant", "category")]
) -> Dict[int, Dict]:
    """
    Detect anomalies across multiple dimensions and combine results.
    
    This provides more comprehensive anomaly detection by looking at:
    - Merchant-level anomalies
    - Category-level anomalies  
    - Merchant-category combination anomalies
    """
    all_anomalies = {}
    
    for dimension in dimensions:
        dim_anomalies = detect_anomalies(df, group_cols=dimension)
        
        # Merge anomalies, keeping track of which dimensions flagged each transaction
        for idx, anomaly in dim_anomalies.items():
            if idx in all_anomalies:
                # Transaction already flagged, update with additional context
                all_anomalies[idx]["dimensions"].append(dimension)
                all_anomalies[idx]["anomaly_score"] = max(
                    all_anomalies[idx]["anomaly_score"],
                    anomaly["anomaly_score"]
                )
            else:
                # New anomaly
                anomaly["dimensions"] = [dimension]
                all_anomalies[idx] = anomaly
    
    return all_anomalies


def mark_anomaly_transactions(df: pd.DataFrame, anomalies: Dict[int, Dict]) -> pd.DataFrame:
    """Mark transactions as anomalies in the DataFrame"""
    df_copy = df.copy()
    df_copy["is_anomaly"] = False
    df_copy["anomaly_score"] = 0.0
    
    for idx, anomaly in anomalies.items():
        if idx in df_copy.index:
            df_copy.loc[idx, "is_anomaly"] = True
            df_copy.loc[idx, "anomaly_score"] = anomaly["anomaly_score"]
    
    return df_copy


def get_anomaly_summary(anomalies: Dict[int, Dict]) -> Dict[str, any]:
    """Generate summary statistics for detected anomalies"""
    if not anomalies:
        return {"total": 0, "high": 0, "low": 0, "avg_score": 0.0}
    
    anomaly_types = [a["anomaly_type"] for a in anomalies.values()]
    scores = [a["anomaly_score"] for a in anomalies.values()]
    
    return {
        "total": len(anomalies),
        "high": anomaly_types.count("high"),
        "low": anomaly_types.count("low"),
        "avg_score": round(np.mean(scores), 2),
        "max_score": round(max(scores), 2)
    }
