from pydantic import BaseModel, Field
from decimal import Decimal
from datetime import datetime
from typing import Optional, List, Dict, Any


class TransactionCreate(BaseModel):
    account_id: int
    date: datetime
    amount: Decimal
    currency: str = "INR"
    merchant: Optional[str] = None
    raw_description: Optional[str] = None


class TransactionResponse(BaseModel):
    id: int
    user_id: int
    account_id: int
    date: datetime
    amount: Decimal
    currency: str
    merchant: Optional[str] = None
    raw_description: Optional[str] = None
    category_id: Optional[int] = None
    is_recurring: bool = False
    is_subscription: bool = False
    is_anomaly: bool = False
    anomaly_score: Optional[Decimal] = None

    class Config:
        from_attributes = True


class CategoryResponse(BaseModel):
    id: int
    name: str
    parent_id: Optional[int] = None
    color: Optional[str] = None
    icon: Optional[str] = None

    class Config:
        from_attributes = True


class AccountCreate(BaseModel):
    name: str
    account_type: str
    currency: str = "INR"


class AccountResponse(BaseModel):
    id: int
    user_id: int
    name: str
    account_type: str
    currency: str

    class Config:
        from_attributes = True


class UploadResponse(BaseModel):
    imported: int
    skipped: int = 0
    errors: List[str] = []


class InsightsResponse(BaseModel):
    total_spend: Decimal
    subscriptions_count: int
    anomalies_count: int
    projected_savings: Decimal
    category_breakdown: Dict[str, Decimal]
    monthly_trend: List[Dict[str, Any]]


class SubscriptionResponse(BaseModel):
    merchant: str
    avg_amount: Decimal
    cadence_days: int
    last_transaction: datetime
    total_transactions: int
    confidence: float = Field(..., ge=0.0, le=1.0)


class AnomalyResponse(BaseModel):
    transaction_id: int
    date: datetime
    merchant: str
    amount: Decimal
    expected_range: str
    anomaly_score: Decimal
    reason: str


class PlanRequest(BaseModel):
    savings_goal: Decimal
    caps: Optional[Dict[str, Decimal]] = None


class PlanActionResponse(BaseModel):
    action_type: str  # "cancel", "cap", "switch"
    target: str
    description: Optional[str] = None
    save_amount: Decimal
    pain_score: Optional[Decimal] = None

    class Config:
        from_attributes = True


class PlanResponse(BaseModel):
    id: int
    month: str
    savings_goal: Decimal
    projected_savings: Decimal
    goal_met: bool
    actions: List[PlanActionResponse]

    class Config:
        from_attributes = True


class WhatIfRequest(BaseModel):
    savings_goal: Decimal
    caps: Optional[Dict[str, Decimal]] = None  # category caps


class WhatIfResponse(BaseModel):
    projected_savings: Decimal
    goal_met: bool
    actions: List[Dict[str, Any]]
    impact_summary: Dict[str, Any]
