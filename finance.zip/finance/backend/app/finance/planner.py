from typing import Dict, List, Optional
import pandas as pd
from datetime import datetime, timedelta
from decimal import Decimal

from .optimizer import BudgetOptimizer
from .subscriptions import detect_subscriptions
from .anomalies import detect_anomalies
from .classifiers import TransactionClassifier


class FinancialPlanner:
    """
    High-level financial planning service that orchestrates optimization.
    
    Combines all analysis modules to generate actionable monthly plans.
    """
    
    def __init__(self):
        self.optimizer = BudgetOptimizer()
        self.classifier = TransactionClassifier()
    
    def create_monthly_plan(
        self,
        transactions_df: pd.DataFrame,
        savings_goal: float,
        target_month: str = None,
        category_caps: Optional[Dict[str, float]] = None
    ) -> Dict:
        """
        Create comprehensive monthly optimization plan.
        
        Args:
            transactions_df: Historical transaction data
            savings_goal: Target monthly savings amount
            target_month: Month for plan (YYYY-MM), defaults to next month
            category_caps: Optional spending caps by category
            
        Returns:
            Complete plan with actions, projections, and insights
        """
        if target_month is None:
            next_month = datetime.now() + timedelta(days=30)
            target_month = next_month.strftime("%Y-%m")
        
        # Step 1: Prepare and classify data
        df_prepared = self._prepare_transaction_data(transactions_df)
        
        # Step 2: Run analysis algorithms
        subscriptions = detect_subscriptions(df_prepared)
        anomalies = detect_anomalies(df_prepared)
        
        # Step 3: Generate optimization plan
        plan = self.optimizer.generate_plan(
            df_prepared, subscriptions, anomalies, savings_goal
        )
        
        # Step 4: Add metadata and projections
        plan.update({
            "target_month": target_month,
            "created_at": datetime.now().isoformat(),
            "data_period": self._get_data_period(df_prepared),
            "insights": self._generate_insights(df_prepared, subscriptions, anomalies),
            "category_caps": category_caps or {},
        })
        
        return plan
    
    def _prepare_transaction_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare and enrich transaction data"""
        df_work = df.copy()
        
        # Ensure required columns exist
        required_cols = ["date", "amount", "merchant"]
        for col in required_cols:
            if col not in df_work.columns:
                raise ValueError(f"Missing required column: {col}")
        
        # Clean and standardize data
        df_work["date"] = pd.to_datetime(df_work["date"])
        df_work["amount"] = pd.to_numeric(df_work["amount"], errors="coerce")
        df_work["merchant"] = df_work["merchant"].fillna("Unknown")
        df_work["raw_description"] = df_work.get("raw_description", "").fillna("")
        
        # Classify transactions if not already classified
        if "category" not in df_work.columns or df_work["category"].isna().any():
            df_work = self.classifier.predict_batch(df_work)
            # Use predicted categories as the main category column
            df_work["category"] = df_work["predicted_category"]
        
        return df_work
    
    def _get_data_period(self, df: pd.DataFrame) -> Dict[str, str]:
        """Get the time period covered by the data"""
        dates = pd.to_datetime(df["date"])
        return {
            "start_date": dates.min().strftime("%Y-%m-%d"),
            "end_date": dates.max().strftime("%Y-%m-%d"),
            "total_days": str((dates.max() - dates.min()).days),
            "months_covered": round((dates.max() - dates.min()).days / 30, 1)
        }
    
    def _generate_insights(
        self, 
        df: pd.DataFrame, 
        subscriptions: Dict, 
        anomalies: Dict
    ) -> Dict:
        """Generate key insights from the analysis"""
        
        # Spending insights
        total_spend = float(df["amount"].abs().sum())
        avg_transaction = float(df["amount"].abs().mean())
        transaction_count = len(df)
        
        # Category breakdown
        category_spend = df.groupby("category")["amount"].sum().abs().sort_values(ascending=False)
        top_categories = category_spend.head(5).to_dict()
        
        # Time-based insights
        df["date"] = pd.to_datetime(df["date"])
        monthly_trend = df.groupby(df["date"].dt.to_period("M"))["amount"].sum().abs()
        
        # Subscription insights
        subscription_spend = sum(sub["avg_amount"] for sub in subscriptions.values())
        if any(sub["cadence_type"] == "weekly" for sub in subscriptions.values()):
            weekly_subs = sum(sub["avg_amount"] * 4.33 for sub in subscriptions.values() if sub["cadence_type"] == "weekly")
            subscription_spend += weekly_subs
        
        # Anomaly insights
        anomaly_impact = sum(anom["actual_amount"] for anom in anomalies.values()) if anomalies else 0
        
        return {
            "total_transactions": transaction_count,
            "total_spend": round(total_spend, 2),
            "avg_transaction_amount": round(avg_transaction, 2),
            "subscription_monthly_cost": round(subscription_spend, 2),
            "subscription_percentage": round((subscription_spend / total_spend * 100) if total_spend > 0 else 0, 1),
            "anomaly_count": len(anomalies),
            "anomaly_total_amount": round(anomaly_impact, 2),
            "top_spending_categories": {k: round(float(v), 2) for k, v in top_categories.items()},
            "spending_trend": "increasing" if len(monthly_trend) > 1 and monthly_trend.iloc[-1] > monthly_trend.iloc[-2] else "stable"
        }
    
    def what_if_analysis(
        self,
        transactions_df: pd.DataFrame,
        savings_goal: float,
        category_caps: Optional[Dict[str, float]] = None,
        max_pain: float = 2.5
    ) -> Dict:
        """
        Perform what-if analysis with different constraints.
        
        Args:
            transactions_df: Historical transaction data
            savings_goal: Target savings goal
            category_caps: Optional spending caps by category
            max_pain: Maximum acceptable pain threshold
            
        Returns:
            What-if scenario results
        """
        df_prepared = self._prepare_transaction_data(transactions_df)
        
        # Run base analysis
        subscriptions = detect_subscriptions(df_prepared)
        anomalies = detect_anomalies(df_prepared)
        
        # Generate plan with constraints
        base_plan = self.optimizer.generate_plan(
            df_prepared, subscriptions, anomalies, savings_goal, max_pain
        )
        
        # Apply category caps if provided
        if category_caps:
            adjusted_actions = self._apply_category_caps(base_plan["actions"], category_caps)
            base_plan["actions"] = adjusted_actions
            base_plan["projected_savings"] = sum(action["save_amount"] for action in adjusted_actions)
            base_plan["goal_met"] = base_plan["projected_savings"] >= savings_goal
        
        # Calculate impact summary
        impact_summary = self._calculate_impact_summary(df_prepared, base_plan, category_caps)
        
        return {
            "scenario": {
                "savings_goal": savings_goal,
                "category_caps": category_caps or {},
                "max_pain": max_pain
            },
            "results": base_plan,
            "impact_summary": impact_summary,
            "sensitivity_analysis": self._sensitivity_analysis(df_prepared, subscriptions, anomalies, savings_goal)
        }
    
    def _apply_category_caps(self, actions: List[Dict], category_caps: Dict[str, float]) -> List[Dict]:
        """Apply category spending caps to optimization actions"""
        adjusted_actions = []
        
        for action in actions:
            if action["type"] == "reduce" and action["target"] in category_caps:
                # Adjust reduction based on cap
                cap_amount = category_caps[action["target"]]
                # This is a simplified approach - in practice, you'd need more sophisticated logic
                adjusted_action = action.copy()
                adjusted_action["save_amount"] = min(action["save_amount"], cap_amount * 0.3)
                adjusted_action["description"] += f" (capped at ₹{cap_amount:,.0f})"
                adjusted_actions.append(adjusted_action)
            else:
                adjusted_actions.append(action)
        
        return adjusted_actions
    
    def _calculate_impact_summary(
        self, 
        df: pd.DataFrame, 
        plan: Dict, 
        category_caps: Optional[Dict[str, float]]
    ) -> Dict:
        """Calculate the impact of the optimization plan"""
        
        current_monthly_spend = self.optimizer._calculate_monthly_spend(df)
        total_current_spend = sum(current_monthly_spend.values())
        
        # Calculate spend reduction by category
        category_impact = {}
        for action in plan["actions"]:
            if action["type"] in ["reduce", "cap"] and action["target"] in current_monthly_spend:
                category_impact[action["target"]] = {
                    "current_spend": current_monthly_spend[action["target"]],
                    "reduction": action["save_amount"],
                    "new_spend": current_monthly_spend[action["target"]] - action["save_amount"],
                    "reduction_percentage": round((action["save_amount"] / current_monthly_spend[action["target"]]) * 100, 1)
                }
        
        return {
            "total_current_monthly_spend": round(total_current_spend, 2),
            "projected_new_monthly_spend": round(total_current_spend - plan["projected_savings"], 2),
            "savings_percentage": round((plan["projected_savings"] / total_current_spend) * 100, 1) if total_current_spend > 0 else 0,
            "category_impacts": category_impact,
            "feasibility_score": self._calculate_feasibility_score(plan["actions"]),
        }
    
    def _calculate_feasibility_score(self, actions: List[Dict]) -> float:
        """Calculate overall feasibility score for the plan (0-1)"""
        if not actions:
            return 0.0
        
        # Weight by action difficulty
        difficulty_weights = {
            "cancel": 0.8,    # Easy to cancel subscriptions
            "reduce": 0.6,    # Moderate difficulty to reduce spending
            "switch": 0.7,    # Moderate difficulty to switch providers
            "cap": 0.9,       # Easy to set spending caps
        }
        
        total_weight = 0
        feasibility_sum = 0
        
        for action in actions:
            weight = difficulty_weights.get(action["type"], 0.5)
            # Inverse of pain score as feasibility (lower pain = higher feasibility)
            feasibility = 1.0 - min(action.get("pain_score", 0.5), 1.0)
            
            feasibility_sum += feasibility * weight * action["save_amount"]
            total_weight += weight * action["save_amount"]
        
        return round(feasibility_sum / total_weight if total_weight > 0 else 0.0, 2)
    
    def _sensitivity_analysis(
        self, 
        df: pd.DataFrame, 
        subscriptions: Dict, 
        anomalies: Dict, 
        base_goal: float
    ) -> Dict:
        """Perform sensitivity analysis for different savings goals"""
        
        sensitivity_results = {}
        test_goals = [base_goal * 0.5, base_goal * 0.75, base_goal, base_goal * 1.25, base_goal * 1.5]
        
        for goal in test_goals:
            plan = self.optimizer.generate_plan(df, subscriptions, anomalies, goal)
            sensitivity_results[f"{goal:.0f}"] = {
                "achievable": plan["goal_met"],
                "projected_savings": plan["projected_savings"],
                "action_count": len(plan["actions"]),
                "pain_score": plan.get("total_pain_score", 0)
            }
        
        return sensitivity_results
