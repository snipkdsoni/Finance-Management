import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from decimal import Decimal
import io
import random
import argparse
from pathlib import Path

from sqlalchemy.orm import Session
from ..db.sql import SessionLocal, get_db
from ..auth.models import User
from .models_sql import Account, Category, Transaction
from .classifiers import create_default_categories, TransactionClassifier


class TransactionIngester:
    """
    Service for ingesting transaction data from various file formats.
    
    Supports CSV, Excel, and OFX files with flexible column mapping.
    """
    
    def __init__(self):
        self.classifier = TransactionClassifier()
        self.column_mappings = {
            # Common column name variations
            "date": ["date", "transaction_date", "txn_date", "Date", "Transaction Date"],
            "amount": ["amount", "Amount", "transaction_amount", "debit", "credit", "Transaction Amount"],
            "merchant": ["merchant", "Merchant", "description", "Description", "payee", "Payee", "vendor"],
            "raw_description": ["description", "Description", "memo", "Memo", "reference", "Reference"],
            "category": ["category", "Category", "type", "Type"],
            "currency": ["currency", "Currency", "CCY"]
        }
    
    def parse_csv_file(self, file_content: bytes, user_id: int) -> Dict[str, any]:
        """
        Parse CSV file and return transaction data.
        
        Args:
            file_content: Raw file bytes
            user_id: User ID for the transactions
            
        Returns:
            Dict with parsing results and transaction data
        """
        try:
            # Try different encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    content_str = file_content.decode(encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise ValueError("Could not decode file with supported encodings")
            
            # Parse CSV with pandas
            df = pd.read_csv(io.StringIO(content_str))
            
            # Map columns to standard names
            df_mapped = self._map_columns(df)
            
            # Validate and clean data
            df_clean = self._clean_transaction_data(df_mapped)
            
            # Convert to transaction records
            transactions = self._dataframe_to_transactions(df_clean, user_id)
            
            return {
                "success": True,
                "transactions": transactions,
                "total_rows": len(df),
                "valid_transactions": len(transactions),
                "errors": []
            }
            
        except Exception as e:
            return {
                "success": False,
                "transactions": [],
                "total_rows": 0,
                "valid_transactions": 0,
                "errors": [str(e)]
            }
    
    def parse_excel_file(self, file_content: bytes, user_id: int, sheet_name: str = None) -> Dict[str, any]:
        """Parse Excel file and return transaction data"""
        try:
            # Read Excel file
            df = pd.read_excel(io.BytesIO(file_content), sheet_name=sheet_name or 0)
            
            # Map columns and process same as CSV
            df_mapped = self._map_columns(df)
            df_clean = self._clean_transaction_data(df_mapped)
            transactions = self._dataframe_to_transactions(df_clean, user_id)
            
            return {
                "success": True,
                "transactions": transactions,
                "total_rows": len(df),
                "valid_transactions": len(transactions),
                "errors": []
            }
            
        except Exception as e:
            return {
                "success": False,
                "transactions": [],
                "total_rows": 0,
                "valid_transactions": 0,
                "errors": [str(e)]
            }
    
    def _map_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Map various column names to standard format"""
        df_mapped = df.copy()
        column_map = {}
        
        # Find best matching columns
        for standard_col, variations in self.column_mappings.items():
            for variation in variations:
                if variation in df.columns:
                    column_map[variation] = standard_col
                    break
        
        # Rename columns
        df_mapped = df_mapped.rename(columns=column_map)
        
        return df_mapped
    
    def _clean_transaction_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean and validate transaction data"""
        df_clean = df.copy()
        
        # Ensure required columns exist
        required_cols = ["date", "amount"]
        for col in required_cols:
            if col not in df_clean.columns:
                raise ValueError(f"Required column '{col}' not found")
        
        # Clean date column
        df_clean["date"] = pd.to_datetime(df_clean["date"], errors="coerce", dayfirst=True)
        
        # Clean amount column - handle different formats
        if df_clean["amount"].dtype == 'object':
            # Remove currency symbols and commas
            df_clean["amount"] = df_clean["amount"].astype(str).str.replace(r'[₹$,]', '', regex=True)
            df_clean["amount"] = df_clean["amount"].str.replace(r'[()]', '-', regex=True)  # Handle (1000) as -1000
        
        df_clean["amount"] = pd.to_numeric(df_clean["amount"], errors="coerce")
        
        # Add default values for missing columns
        if "merchant" not in df_clean.columns:
            df_clean["merchant"] = df_clean.get("raw_description", "Unknown Merchant")
        
        if "raw_description" not in df_clean.columns:
            df_clean["raw_description"] = df_clean.get("merchant", "")
        
        if "currency" not in df_clean.columns:
            df_clean["currency"] = "INR"
        
        # Remove invalid rows
        df_clean = df_clean.dropna(subset=["date", "amount"])
        df_clean = df_clean[df_clean["amount"] != 0]
        
        return df_clean
    
    def _dataframe_to_transactions(self, df: pd.DataFrame, user_id: int) -> List[Dict]:
        """Convert cleaned DataFrame to transaction dictionaries"""
        transactions = []
        
        for _, row in df.iterrows():
            transaction = {
                "user_id": user_id,
                "date": row["date"].isoformat() if pd.notna(row["date"]) else None,
                "amount": float(row["amount"]) if pd.notna(row["amount"]) else 0.0,
                "currency": row.get("currency", "INR"),
                "merchant": str(row.get("merchant", "")).strip() or "Unknown",
                "raw_description": str(row.get("raw_description", "")).strip(),
                "category": str(row.get("category", "")).strip() if pd.notna(row.get("category")) else None,
            }
            transactions.append(transaction)
        
        return transactions
    
    def save_transactions_to_db(self, transactions: List[Dict], account_id: int) -> Tuple[int, List[str]]:
        """
        Save transactions to database.
        
        Returns:
            Tuple of (saved_count, error_messages)
        """
        db = SessionLocal()
        saved_count = 0
        errors = []
        
        try:
            for txn_data in transactions:
                try:
                    # Create transaction record
                    transaction = Transaction(
                        user_id=txn_data["user_id"],
                        account_id=account_id,
                        date=datetime.fromisoformat(txn_data["date"]),
                        amount=Decimal(str(txn_data["amount"])),
                        currency=txn_data.get("currency", "INR"),
                        merchant=txn_data["merchant"],
                        raw_description=txn_data.get("raw_description", ""),
                    )
                    
                    db.add(transaction)
                    saved_count += 1
                    
                except Exception as e:
                    errors.append(f"Error saving transaction: {str(e)}")
            
            db.commit()
            
        except Exception as e:
            db.rollback()
            errors.append(f"Database error: {str(e)}")
        finally:
            db.close()
        
        return saved_count, errors


class SeedDataGenerator:
    """
    Generate realistic seed data for demo purposes.
    
    Creates 6 months of synthetic transaction data with realistic patterns.
    """
    
    def __init__(self):
        self.categories = {
            "Food & Dining": {
                "merchants": ["Swiggy", "Zomato", "McDonald's", "Starbucks", "Local Restaurant", "Cafe Coffee Day"],
                "avg_amount": (150, 800),
                "frequency": 15  # transactions per month
            },
            "Groceries": {
                "merchants": ["BigBasket", "Grofers", "D-Mart", "Local Store", "Spencer's"],
                "avg_amount": (500, 2500),
                "frequency": 8
            },
            "Transport": {
                "merchants": ["Uber", "Ola", "Metro Card", "Petrol Pump", "Parking"],
                "avg_amount": (50, 400),
                "frequency": 20
            },
            "Entertainment": {
                "merchants": ["Netflix", "Amazon Prime", "BookMyShow", "PVR Cinemas", "Spotify"],
                "avg_amount": (200, 1200),
                "frequency": 6
            },
            "Shopping": {
                "merchants": ["Amazon", "Flipkart", "Myntra", "Mall Purchase", "Electronics Store"],
                "avg_amount": (800, 5000),
                "frequency": 5
            },
            "Utilities": {
                "merchants": ["Electricity Bill", "Internet Bill", "Mobile Recharge", "Water Bill"],
                "avg_amount": (800, 2500),
                "frequency": 3
            },
            "Subscriptions": {
                "merchants": ["Netflix", "Spotify Premium", "Gym Membership", "Newspaper", "Amazon Prime"],
                "avg_amount": (200, 1500),
                "frequency": 2,
                "recurring": True
            },
            "Health": {
                "merchants": ["Pharmacy", "Doctor Visit", "Gym", "Health Checkup"],
                "avg_amount": (300, 2000),
                "frequency": 4
            }
        }
    
    def generate_user_transactions(self, user_id: int, account_id: int, months: int = 6) -> List[Transaction]:
        """Generate realistic transactions for a user over specified months"""
        
        transactions = []
        start_date = datetime.now() - timedelta(days=months * 30)
        
        for category, config in self.categories.items():
            category_transactions = self._generate_category_transactions(
                user_id, account_id, category, config, start_date, months
            )
            transactions.extend(category_transactions)
        
        # Sort by date
        transactions.sort(key=lambda x: x.date)
        
        return transactions
    
    def _generate_category_transactions(
        self, 
        user_id: int, 
        account_id: int, 
        category: str, 
        config: Dict, 
        start_date: datetime, 
        months: int
    ) -> List[Transaction]:
        """Generate transactions for a specific category"""
        
        transactions = []
        is_recurring = config.get("recurring", False)
        
        if is_recurring:
            # Generate recurring transactions (subscriptions)
            transactions.extend(
                self._generate_recurring_transactions(
                    user_id, account_id, category, config, start_date, months
                )
            )
        else:
            # Generate random transactions
            transactions.extend(
                self._generate_random_transactions(
                    user_id, account_id, category, config, start_date, months
                )
            )
        
        return transactions
    
    def _generate_recurring_transactions(
        self, 
        user_id: int, 
        account_id: int, 
        category: str, 
        config: Dict, 
        start_date: datetime, 
        months: int
    ) -> List[Transaction]:
        """Generate recurring subscription transactions"""
        
        transactions = []
        
        for merchant in config["merchants"]:
            if random.random() > 0.7:  # 70% chance to have this subscription
                continue
                
            # Pick a recurring amount and date
            amount = random.uniform(*config["avg_amount"])
            day_of_month = random.randint(1, 28)
            
            for month in range(months):
                txn_date = start_date + timedelta(days=month * 30 + day_of_month)
                
                # Add some variance to amount (±10%)
                varied_amount = amount * random.uniform(0.9, 1.1)
                
                transaction = Transaction(
                    user_id=user_id,
                    account_id=account_id,
                    date=txn_date,
                    amount=Decimal(str(round(varied_amount, 2))),
                    currency="INR",
                    merchant=merchant,
                    raw_description=f"{merchant} subscription",
                    is_subscription=True,
                    is_recurring=True
                )
                transactions.append(transaction)
        
        return transactions
    
    def _generate_random_transactions(
        self, 
        user_id: int, 
        account_id: int, 
        category: str, 
        config: Dict, 
        start_date: datetime, 
        months: int
    ) -> List[Transaction]:
        """Generate random transactions for a category"""
        
        transactions = []
        total_transactions = config["frequency"] * months
        
        for _ in range(total_transactions):
            # Random date within the period
            days_offset = random.randint(0, months * 30)
            txn_date = start_date + timedelta(days=days_offset)
            
            # Random merchant and amount
            merchant = random.choice(config["merchants"])
            amount = random.uniform(*config["avg_amount"])
            
            # Add some outliers (5% chance)
            if random.random() < 0.05:
                amount *= random.uniform(2.0, 4.0)  # Anomalous high amount
            
            transaction = Transaction(
                user_id=user_id,
                account_id=account_id,
                date=txn_date,
                amount=Decimal(str(round(amount, 2))),
                currency="INR",
                merchant=merchant,
                raw_description=f"Purchase at {merchant}",
            )
            transactions.append(transaction)
        
        return transactions
    
    def create_demo_user_and_data(self) -> Dict[str, any]:
        """Create complete demo user with transactions and categories"""
        
        db = SessionLocal()
        
        try:
            # Create demo user
            from ..auth.security import hash_password
            
            demo_user = User(
                email="demo@fin.com",
                hashed_password=hash_password("finpass"),
                full_name="Demo User",
                is_active=True
            )
            
            # Check if user already exists
            existing_user = db.query(User).filter(User.email == "demo@fin.com").first()
            if existing_user:
                db.close()
                return {"message": "Demo user already exists", "user_id": existing_user.id}
            
            db.add(demo_user)
            db.commit()
            db.refresh(demo_user)
            
            # Create default categories
            categories = create_default_categories()
            for cat_data in categories:
                category = Category(
                    name=cat_data["name"],
                    color=cat_data["color"],
                    icon=cat_data["icon"]
                )
                db.add(category)
            
            db.commit()
            
            # Create demo account
            demo_account = Account(
                user_id=demo_user.id,
                name="HDFC Savings",
                account_type="savings",
                currency="INR"
            )
            db.add(demo_account)
            db.commit()
            db.refresh(demo_account)
            
            # Generate transactions
            transactions = self.generate_user_transactions(demo_user.id, demo_account.id, 6)
            
            for transaction in transactions:
                db.add(transaction)
            
            db.commit()
            
            return {
                "message": "Demo data created successfully",
                "user_id": demo_user.id,
                "account_id": demo_account.id,
                "transactions_count": len(transactions)
            }
            
        except Exception as e:
            db.rollback()
            raise e
        finally:
            db.close()


def main():
    """CLI entry point for seeding data"""
    parser = argparse.ArgumentParser(description="Seed finance data")
    parser.add_argument("--seed", action="store_true", help="Generate demo data")
    
    args = parser.parse_args()
    
    if args.seed:
        generator = SeedDataGenerator()
        result = generator.create_demo_user_and_data()
        print(f"✅ {result['message']}")
        print(f"📊 Created {result.get('transactions_count', 0)} transactions")


if __name__ == "__main__":
    main()
