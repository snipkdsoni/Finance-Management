import numpy as np
import pandas as pd
from collections import defaultdict
from typing import Set, Dict, List, Tuple
from datetime import datetime


def detect_subscriptions(
    df: pd.DataFrame, 
    date_col: str = "date", 
    merchant_col: str = "merchant", 
    amount_col: str = "amount",
    min_transactions: int = 3
) -> Dict[str, Dict]:
    """
    Detect subscriptions using periodicity analysis and autocorrelation.
    
    Algorithm:
    1. Group transactions by merchant
    2. Calculate inter-arrival days between consecutive transactions
    3. Detect periodic patterns using median and MAD (Median Absolute Deviation)
    4. Validate patterns meet subscription criteria (28-31 days monthly, 6-8 days weekly)
    
    Returns:
        Dict mapping merchant names to subscription metadata
    """
    subscriptions = {}
    
    for merchant, group in df.groupby(merchant_col):
        if len(group) < min_transactions:
            continue
            
        # Sort by date and calculate inter-arrival days
        group_sorted = group.sort_values(date_col)
        dates = pd.to_datetime(group_sorted[date_col])
        gaps = dates.diff().dt.days.dropna()
        
        if len(gaps) < 2:
            continue
            
        # Calculate robust statistics for gap analysis
        median_gap = np.median(gaps)
        mad = np.median(np.abs(gaps - median_gap))  # Median Absolute Deviation
        
        # Periodicity thresholds
        monthly_range = (28, 31)  # Monthly subscriptions
        weekly_range = (6, 8)     # Weekly subscriptions
        tolerance = max(2, mad)   # Adaptive tolerance based on variance
        
        is_subscription = False
        cadence_type = None
        confidence = 0.0
        
        # Check for monthly pattern
        if monthly_range[0] <= median_gap <= monthly_range[1] and tolerance <= 3:
            is_subscription = True
            cadence_type = "monthly"
            confidence = 1.0 - (tolerance / 5.0)  # Higher confidence for lower variance
            
        # Check for weekly pattern
        elif weekly_range[0] <= median_gap <= weekly_range[1] and tolerance <= 2:
            is_subscription = True
            cadence_type = "weekly"
            confidence = 1.0 - (tolerance / 3.0)
            
        # Additional validation: check amount consistency
        amounts = group_sorted[amount_col].abs()
        amount_variance = np.std(amounts) / np.mean(amounts) if np.mean(amounts) > 0 else 1
        
        # Reduce confidence if amounts are highly variable (not typical for subscriptions)
        if amount_variance > 0.3:
            confidence *= 0.7
            
        if is_subscription and confidence >= 0.5:
            subscriptions[merchant] = {
                "cadence_days": int(median_gap),
                "cadence_type": cadence_type,
                "avg_amount": float(amounts.mean()),
                "amount_std": float(amounts.std()),
                "confidence": round(confidence, 2),
                "transaction_count": len(group_sorted),
                "last_transaction": dates.iloc[-1].isoformat(),
                "median_gap": int(median_gap),
                "gap_variability": round(tolerance, 1)
            }
    
    return subscriptions


def autocorrelation_analysis(gaps: np.ndarray, max_lag: int = 5) -> float:
    """
    Compute autocorrelation of inter-arrival gaps to detect periodicity.
    Higher autocorrelation at lag=1 suggests regular patterns.
    """
    if len(gaps) < 3:
        return 0.0
        
    # Normalize gaps
    gaps_norm = (gaps - np.mean(gaps)) / (np.std(gaps) + 1e-8)
    
    # Compute autocorrelation at lag 1
    if len(gaps_norm) > 1:
        corr = np.corrcoef(gaps_norm[:-1], gaps_norm[1:])[0, 1]
        return corr if not np.isnan(corr) else 0.0
    
    return 0.0


def enhanced_subscription_detection(
    df: pd.DataFrame,
    date_col: str = "date",
    merchant_col: str = "merchant", 
    amount_col: str = "amount"
) -> Dict[str, Dict]:
    """
    Enhanced subscription detection with autocorrelation and merchant clustering.
    """
    base_subscriptions = detect_subscriptions(df, date_col, merchant_col, amount_col)
    
    # Enhance with autocorrelation analysis
    for merchant, metadata in base_subscriptions.items():
        merchant_data = df[df[merchant_col] == merchant].sort_values(date_col)
        dates = pd.to_datetime(merchant_data[date_col])
        gaps = dates.diff().dt.days.dropna().values
        
        if len(gaps) > 2:
            autocorr = autocorrelation_analysis(gaps)
            metadata["autocorrelation"] = round(autocorr, 3)
            
            # Boost confidence for high autocorrelation
            if autocorr > 0.5:
                metadata["confidence"] = min(1.0, metadata["confidence"] * 1.2)
    
    # Filter by final confidence threshold
    return {k: v for k, v in base_subscriptions.items() if v["confidence"] >= 0.6}


# Utility functions for integration
def mark_subscription_transactions(df: pd.DataFrame, subscriptions: Dict[str, Dict]) -> pd.DataFrame:
    """Mark transactions as subscriptions in the DataFrame"""
    df_copy = df.copy()
    df_copy["is_subscription"] = df_copy["merchant"].isin(subscriptions.keys())
    return df_copy


def get_subscription_merchants(df: pd.DataFrame) -> Set[str]:
    """Get set of merchants identified as subscriptions"""
    subscriptions = detect_subscriptions(df)
    return set(subscriptions.keys())
