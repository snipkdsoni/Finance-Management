from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import pandas as pd
import numpy as np
from decimal import Decimal


@dataclass
class OptimizationAction:
    """Individual optimization action with cost/benefit analysis"""
    action_type: str  # "cancel", "cap", "switch", "reduce"
    target: str       # merchant name or category
    description: str
    save_amount: float
    pain_score: float  # 0.0 = no pain, 1.0 = maximum pain
    feasibility: float = 1.0  # How realistic this action is
    
    @property
    def efficiency(self) -> float:
        """Savings per unit of pain (higher is better)"""
        return self.save_amount / (self.pain_score + 0.01)


class BudgetOptimizer:
    """
    Advanced budget optimizer using knapsack-style algorithm with pain scoring.
    
    Generates optimization recommendations to meet savings goals while minimizing
    lifestyle disruption using dynamic programming and heuristics.
    """
    
    def __init__(self):
        self.pain_weights = {
            # Action type pain multipliers
            "cancel": 0.8,      # Canceling subscriptions - moderate pain
            "reduce": 0.6,      # Reducing spending in a category - low-medium pain  
            "switch": 0.4,      # Switching to cheaper alternatives - low pain
            "cap": 0.5,         # Setting spending caps - low-medium pain
        }
        
        self.category_pain = {
            # Category-specific pain scores (0-1)
            "Food & Dining": 0.7,      # High pain to reduce dining out
            "Entertainment": 0.4,       # Medium pain for entertainment cuts
            "Shopping": 0.3,            # Low pain for shopping cuts
            "Transport": 0.8,           # High pain for transport cuts
            "Groceries": 0.9,           # Very high pain for grocery cuts
            "Utilities": 0.95,          # Near maximum pain for utility cuts
            "Health": 0.98,             # Maximum pain for health cuts
            "Education": 0.95,          # Very high pain for education cuts
            "Subscriptions": 0.2,       # Very low pain for subscription cancellations
            "Miscellaneous": 0.3,       # Low pain for misc cuts
        }
    
    def generate_optimization_actions(
        self, 
        transactions_df: pd.DataFrame,
        subscriptions: Dict[str, Dict],
        anomalies: Dict[int, Dict],
        current_month_spend: Dict[str, float],
        savings_goal: float
    ) -> List[OptimizationAction]:
        """
        Generate potential optimization actions based on spending patterns.
        
        Returns list of actions ranked by efficiency (savings/pain ratio)
        """
        actions = []
        
        # 1. Subscription cancellation actions
        actions.extend(self._generate_subscription_actions(subscriptions))
        
        # 2. Category reduction actions
        actions.extend(self._generate_category_reduction_actions(current_month_spend))
        
        # 3. Merchant switching actions
        actions.extend(self._generate_switching_actions(transactions_df))
        
        # 4. Anomaly-based actions
        actions.extend(self._generate_anomaly_actions(transactions_df, anomalies))
        
        # Sort by efficiency (savings per pain point)
        actions.sort(key=lambda x: x.efficiency, reverse=True)
        
        return actions
    
    def _generate_subscription_actions(self, subscriptions: Dict[str, Dict]) -> List[OptimizationAction]:
        """Generate actions to cancel underutilized subscriptions"""
        actions = []
        
        for merchant, sub_data in subscriptions.items():
            monthly_cost = sub_data["avg_amount"]
            if sub_data["cadence_type"] == "weekly":
                monthly_cost *= 4.33  # Convert weekly to monthly
            
            # Assume some subscriptions are more cancellable than others
            feasibility = self._assess_subscription_cancellability(merchant, sub_data)
            
            if feasibility > 0.3:  # Only suggest if reasonably feasible
                pain = self.pain_weights["cancel"] * feasibility
                
                action = OptimizationAction(
                    action_type="cancel",
                    target=merchant,
                    description=f"Cancel {merchant} subscription",
                    save_amount=monthly_cost,
                    pain_score=pain,
                    feasibility=feasibility
                )
                actions.append(action)
        
        return actions
    
    def _generate_category_reduction_actions(self, current_spend: Dict[str, float]) -> List[OptimizationAction]:
        """Generate actions to reduce spending in high-spend categories"""
        actions = []
        
        # Focus on categories with high spend and reasonable reducibility
        reducible_categories = ["Food & Dining", "Shopping", "Entertainment", "Miscellaneous"]
        
        for category, amount in current_spend.items():
            if category in reducible_categories and amount > 2000:  # Focus on significant amounts
                
                # Suggest 20-40% reduction
                reduction_percentages = [0.2, 0.3, 0.4]
                
                for reduction in reduction_percentages:
                    save_amount = amount * reduction
                    pain = self.category_pain.get(category, 0.5) * reduction * 2  # Higher reduction = more pain
                    
                    action = OptimizationAction(
                        action_type="reduce",
                        target=category,
                        description=f"Reduce {category} spending by {int(reduction*100)}%",
                        save_amount=save_amount,
                        pain_score=min(pain, 1.0)
                    )
                    actions.append(action)
        
        return actions
    
    def _generate_switching_actions(self, transactions_df: pd.DataFrame) -> List[OptimizationAction]:
        """Generate actions to switch to cheaper alternatives"""
        actions = []
        
        # Analyze expensive merchants and suggest cheaper alternatives
        merchant_spend = transactions_df.groupby("merchant")["amount"].agg(['sum', 'mean', 'count']).abs()
        expensive_merchants = merchant_spend[merchant_spend['mean'] > 500].head(5)
        
        switching_suggestions = {
            # Common switching opportunities
            "uber": {"alternative": "Metro/Bus", "savings_pct": 0.6},
            "ola": {"alternative": "Metro/Bus", "savings_pct": 0.6},
            "swiggy": {"alternative": "Home cooking", "savings_pct": 0.7},
            "zomato": {"alternative": "Home cooking", "savings_pct": 0.7},
            "amazon": {"alternative": "Local stores", "savings_pct": 0.2},
        }
        
        for merchant, data in expensive_merchants.iterrows():
            merchant_lower = merchant.lower()
            for key, suggestion in switching_suggestions.items():
                if key in merchant_lower:
                    monthly_save = data['sum'] * suggestion["savings_pct"] / 4  # Assume partial switching
                    
                    action = OptimizationAction(
                        action_type="switch",
                        target=merchant,
                        description=f"Switch from {merchant} to {suggestion['alternative']}",
                        save_amount=monthly_save,
                        pain_score=self.pain_weights["switch"]
                    )
                    actions.append(action)
        
        return actions
    
    def _generate_anomaly_actions(self, transactions_df: pd.DataFrame, anomalies: Dict[int, Dict]) -> List[OptimizationAction]:
        """Generate actions based on detected anomalies"""
        actions = []
        
        # Focus on high-value anomalies that suggest overspending
        high_anomalies = {k: v for k, v in anomalies.items() if v["anomaly_type"] == "high" and v["actual_amount"] > 1000}
        
        if len(high_anomalies) > 2:  # Multiple high anomalies suggest pattern
            total_excess = sum(a["actual_amount"] - a["group_median"] for a in high_anomalies.values())
            monthly_excess = total_excess / 6  # Assume data spans 6 months
            
            action = OptimizationAction(
                action_type="cap",
                target="Anomalous spending",
                description=f"Set spending alerts to prevent anomalous high transactions",
                save_amount=monthly_excess * 0.5,  # Assume 50% reduction in anomalies
                pain_score=0.2  # Low pain for setting alerts
            )
            actions.append(action)
        
        return actions
    
    def _assess_subscription_cancellability(self, merchant: str, sub_data: Dict) -> float:
        """Assess how feasible it is to cancel a subscription (0-1)"""
        merchant_lower = merchant.lower()
        
        # Essential services (low cancellability)
        if any(keyword in merchant_lower for keyword in ["electricity", "gas", "water", "internet", "mobile"]):
            return 0.1
        
        # Semi-essential (medium cancellability)  
        if any(keyword in merchant_lower for keyword in ["gym", "insurance"]):
            return 0.5
        
        # Entertainment/luxury (high cancellability)
        if any(keyword in merchant_lower for keyword in ["netflix", "spotify", "prime", "gaming"]):
            return 0.8
        
        # Default medium cancellability
        return 0.6
    
    def optimize_with_knapsack(
        self,
        actions: List[OptimizationAction],
        savings_goal: float,
        max_pain: float = 3.0
    ) -> Tuple[List[OptimizationAction], float]:
        """
        Use knapsack-style DP to find optimal combination of actions.
        
        Args:
            actions: List of potential actions
            savings_goal: Target savings amount
            max_pain: Maximum acceptable pain score
            
        Returns:
            Tuple of (selected_actions, total_savings)
        """
        n = len(actions)
        if n == 0:
            return [], 0.0
        
        # First try greedy approach for efficiency
        selected_greedy, savings_greedy = self._greedy_selection(actions, savings_goal, max_pain)
        
        if savings_greedy >= savings_goal or n > 50:  # Use greedy for large problems
            return selected_greedy, savings_greedy
        
        # Use DP for smaller problems or when greedy doesn't meet goal
        return self._dp_knapsack(actions, savings_goal, max_pain)
    
    def _greedy_selection(
        self,
        actions: List[OptimizationAction],
        savings_goal: float,
        max_pain: float
    ) -> Tuple[List[OptimizationAction], float]:
        """Greedy selection by efficiency ratio"""
        selected = []
        total_savings = 0.0
        total_pain = 0.0
        
        # Sort by efficiency (already sorted in generate_optimization_actions)
        for action in actions:
            if total_pain + action.pain_score <= max_pain:
                selected.append(action)
                total_savings += action.save_amount
                total_pain += action.pain_score
                
                if total_savings >= savings_goal:
                    break
        
        return selected, total_savings
    
    def _dp_knapsack(
        self,
        actions: List[OptimizationAction],
        savings_goal: float,
        max_pain: float
    ) -> Tuple[List[OptimizationAction], float]:
        """Dynamic programming knapsack solution"""
        n = len(actions)
        
        # Discretize pain scores to integers (multiply by 100)
        pain_scale = 100
        W = int(max_pain * pain_scale)
        
        # DP table: dp[i][w] = maximum savings using first i actions with pain <= w
        dp = [[0.0 for _ in range(W + 1)] for _ in range(n + 1)]
        
        # Fill DP table
        for i in range(1, n + 1):
            action = actions[i - 1]
            weight = int(action.pain_score * pain_scale)
            value = action.save_amount
            
            for w in range(W + 1):
                # Don't take this action
                dp[i][w] = dp[i - 1][w]
                
                # Take this action if it fits
                if weight <= w:
                    dp[i][w] = max(dp[i][w], dp[i - 1][w - weight] + value)
        
        # Reconstruct solution
        selected_actions = []
        w = W
        total_savings = dp[n][w]
        
        for i in range(n, 0, -1):
            action = actions[i - 1]
            weight = int(action.pain_score * pain_scale)
            
            if w >= weight and dp[i][w] != dp[i - 1][w]:
                selected_actions.append(action)
                w -= weight
        
        return selected_actions[::-1], total_savings
    
    def generate_plan(
        self,
        transactions_df: pd.DataFrame,
        subscriptions: Dict[str, Dict],
        anomalies: Dict[int, Dict],
        savings_goal: float,
        max_pain: float = 2.5
    ) -> Dict:
        """
        Generate complete optimization plan.
        
        Returns:
            Dict with plan details, actions, and projections
        """
        # Calculate current monthly spending by category
        monthly_spend = self._calculate_monthly_spend(transactions_df)
        
        # Generate all possible actions
        all_actions = self.generate_optimization_actions(
            transactions_df, subscriptions, anomalies, monthly_spend, savings_goal
        )
        
        # Optimize action selection
        selected_actions, total_savings = self.optimize_with_knapsack(
            all_actions, savings_goal, max_pain
        )
        
        return {
            "savings_goal": savings_goal,
            "projected_savings": round(total_savings, 2),
            "goal_met": total_savings >= savings_goal,
            "total_pain_score": round(sum(a.pain_score for a in selected_actions), 2),
            "actions": [
                {
                    "type": a.action_type,
                    "target": a.target,
                    "description": a.description,
                    "save_amount": round(a.save_amount, 2),
                    "pain_score": round(a.pain_score, 2),
                    "efficiency": round(a.efficiency, 2)
                }
                for a in selected_actions
            ],
            "alternative_actions": [
                {
                    "type": a.action_type,
                    "target": a.target,
                    "description": a.description,
                    "save_amount": round(a.save_amount, 2),
                    "pain_score": round(a.pain_score, 2)
                }
                for a in all_actions[:10] if a not in selected_actions
            ]
        }
    
    def _calculate_monthly_spend(self, transactions_df: pd.DataFrame) -> Dict[str, float]:
        """Calculate average monthly spending by category"""
        df = transactions_df.copy()
        df["date"] = pd.to_datetime(df["date"])
        df["amount"] = df["amount"].abs()
        
        # Group by category and calculate totals
        category_totals = df.groupby("predicted_category" if "predicted_category" in df.columns else "category")["amount"].sum()
        
        # Convert to monthly averages (assuming data spans multiple months)
        date_range = (df["date"].max() - df["date"].min()).days
        months = max(1, date_range / 30)
        
        monthly_spend = {cat: float(total / months) for cat, total in category_totals.items()}
        return monthly_spend
