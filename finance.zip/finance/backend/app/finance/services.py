from typing import Dict, List, Optional
import pandas as pd
from datetime import datetime, timedelta
from decimal import Decimal
from sqlalchemy.orm import Session
from pymongo.database import Database

from .models_sql import Transaction, Account, Category, Plan, PlanAction
from .models_mongo import MongoInsights, MongoModel
from .subscriptions import detect_subscriptions, mark_subscription_transactions
from .anomalies import detect_anomalies, mark_anomaly_transactions
from .classifiers import TransactionClassifier
from .planner import FinancialPlanner
from .ingestion import TransactionIngester


class FinanceService:
    """
    Main service layer for finance operations.
    
    Orchestrates all finance-related functionality including analysis,
    optimization, and data management.
    """
    
    def __init__(self, db: Session, mongo_db: Database):
        self.db = db
        self.mongo_db = mongo_db
        self.mongo_insights = MongoInsights(mongo_db)
        self.mongo_models = MongoModel(mongo_db)
        self.classifier = TransactionClassifier()
        self.planner = FinancialPlanner()
        self.ingester = TransactionIngester()
    
    def get_user_insights(self, user_id: int, window_days: int = 30) -> Dict:
        """
        Get comprehensive financial insights for a user.
        
        Uses caching to improve performance for repeated requests.
        """
        cache_key = f"insights_{user_id}_{window_days}"
        
        # Try to get cached insights
        cached = self.mongo_insights.get_cached_insights(user_id, cache_key)
        if cached:
            return cached
        
        # Generate fresh insights
        insights = self._generate_user_insights(user_id, window_days)
        
        # Cache for 6 hours
        self.mongo_insights.cache_insights(user_id, cache_key, insights, ttl_hours=6)
        
        return insights
    
    def _generate_user_insights(self, user_id: int, window_days: int) -> Dict:
        """Generate comprehensive insights for a user"""
        
        # Get transactions within window
        cutoff_date = datetime.now() - timedelta(days=window_days)
        transactions = self.db.query(Transaction).filter(
            Transaction.user_id == user_id,
            Transaction.date >= cutoff_date
        ).all()
        
        if not transactions:
            return self._empty_insights()
        
        # Convert to DataFrame for analysis
        df = self._transactions_to_dataframe(transactions)
        
        # Run analysis algorithms
        subscriptions = detect_subscriptions(df)
        anomalies = detect_anomalies(df)
        
        # Classification if needed
        if "category" not in df.columns or df["category"].isna().any():
            df = self.classifier.predict_batch(df)
        
        # Calculate KPIs
        total_spend = float(df["amount"].abs().sum())
        transaction_count = len(df)
        avg_transaction = float(df["amount"].abs().mean()) if transaction_count > 0 else 0
        
        # Category breakdown
        category_breakdown = {}
        if "predicted_category" in df.columns:
            category_totals = df.groupby("predicted_category")["amount"].sum().abs()
            category_breakdown = {k: float(v) for k, v in category_totals.items()}
        
        # Monthly trend
        df["date"] = pd.to_datetime(df["date"])
        monthly_trend = df.groupby(df["date"].dt.to_period("M"))["amount"].sum().abs()
        trend_data = [
            {
                "month": str(period),
                "amount": float(amount),
                "transactions": len(df[df["date"].dt.to_period("M") == period])
            }
            for period, amount in monthly_trend.items()
        ]
        
        # Subscription summary
        subscription_cost = sum(sub["avg_amount"] for sub in subscriptions.values())
        
        # Projected savings (simplified)
        projected_savings = self._estimate_savings_potential(df, subscriptions, anomalies)
        
        return {
            "total_spend": round(total_spend, 2),
            "subscriptions_count": len(subscriptions),
            "anomalies_count": len(anomalies),
            "projected_savings": round(projected_savings, 2),
            "category_breakdown": category_breakdown,
            "monthly_trend": trend_data,
            "subscription_details": subscriptions,
            "anomaly_details": anomalies,
            "transaction_count": transaction_count,
            "avg_transaction_amount": round(avg_transaction, 2),
            "analysis_period": {
                "days": window_days,
                "start_date": cutoff_date.strftime("%Y-%m-%d"),
                "end_date": datetime.now().strftime("%Y-%m-%d")
            }
        }
    
    def get_subscription_analysis(self, user_id: int) -> List[Dict]:
        """Get detailed subscription analysis"""
        
        transactions = self.db.query(Transaction).filter(
            Transaction.user_id == user_id
        ).all()
        
        if not transactions:
            return []
        
        df = self._transactions_to_dataframe(transactions)
        subscriptions = detect_subscriptions(df)
        
        # Convert to API response format
        subscription_list = []
        for merchant, data in subscriptions.items():
            subscription_list.append({
                "merchant": merchant,
                "avg_amount": round(data["avg_amount"], 2),
                "cadence_days": data["cadence_days"],
                "last_transaction": data["last_transaction"],
                "total_transactions": data["transaction_count"],
                "confidence": data["confidence"],
                "cadence_type": data.get("cadence_type", "unknown"),
                "monthly_cost": round(
                    data["avg_amount"] * (4.33 if data.get("cadence_type") == "weekly" else 1), 
                    2
                )
            })
        
        return sorted(subscription_list, key=lambda x: x["monthly_cost"], reverse=True)
    
    def get_anomaly_analysis(self, user_id: int) -> List[Dict]:
        """Get detailed anomaly analysis"""
        
        transactions = self.db.query(Transaction).filter(
            Transaction.user_id == user_id
        ).all()
        
        if not transactions:
            return []
        
        df = self._transactions_to_dataframe(transactions)
        anomalies = detect_anomalies(df)
        
        # Convert to API response format
        anomaly_list = []
        for idx, data in anomalies.items():
            if idx < len(df):
                transaction = df.iloc[idx]
                anomaly_list.append({
                    "transaction_id": data.get("transaction_id", idx),
                    "date": transaction["date"].strftime("%Y-%m-%d"),
                    "merchant": transaction["merchant"],
                    "amount": round(data["actual_amount"], 2),
                    "expected_range": data["expected_range"],
                    "anomaly_score": data["anomaly_score"],
                    "reason": data["reason"],
                    "anomaly_type": data["anomaly_type"]
                })
        
        return sorted(anomaly_list, key=lambda x: x["anomaly_score"], reverse=True)
    
    def create_optimization_plan(self, user_id: int, savings_goal: float, category_caps: Optional[Dict[str, float]] = None) -> Dict:
        """Create monthly optimization plan"""
        
        transactions = self.db.query(Transaction).filter(
            Transaction.user_id == user_id
        ).all()
        
        if not transactions:
            return {"error": "No transactions found"}
        
        df = self._transactions_to_dataframe(transactions)
        
        # Generate plan using financial planner
        plan = self.planner.create_monthly_plan(df, savings_goal, category_caps=category_caps)
        
        # Save plan to database
        plan_id = self._save_plan_to_db(user_id, plan)
        plan["id"] = plan_id
        
        return plan
    
    def what_if_analysis(self, user_id: int, savings_goal: float, category_caps: Optional[Dict[str, float]] = None) -> Dict:
        """Perform what-if analysis"""
        
        transactions = self.db.query(Transaction).filter(
            Transaction.user_id == user_id
        ).all()
        
        if not transactions:
            return {"error": "No transactions found"}
        
        df = self._transactions_to_dataframe(transactions)
        
        # Run what-if analysis
        results = self.planner.what_if_analysis(df, savings_goal, category_caps)
        
        return results
    
    def upload_transactions(self, user_id: int, file_content: bytes, filename: str, account_id: int) -> Dict:
        """Upload and process transaction file"""
        
        file_ext = filename.lower().split('.')[-1]
        
        if file_ext == 'csv':
            result = self.ingester.parse_csv_file(file_content, user_id)
        elif file_ext in ['xlsx', 'xls']:
            result = self.ingester.parse_excel_file(file_content, user_id)
        else:
            return {"success": False, "error": "Unsupported file format"}
        
        if not result["success"]:
            return result
        
        # Save to database
        saved_count, errors = self.ingester.save_transactions_to_db(
            result["transactions"], account_id
        )
        
        # Clear insights cache for user
        self.mongo_insights.clear_user_cache(user_id)
        
        return {
            "success": True,
            "imported": saved_count,
            "skipped": result["total_rows"] - saved_count,
            "errors": errors
        }
    
    def get_user_accounts(self, user_id: int) -> List[Dict]:
        """Get user's accounts"""
        accounts = self.db.query(Account).filter(Account.user_id == user_id).all()
        
        return [
            {
                "id": acc.id,
                "name": acc.name,
                "account_type": acc.account_type,
                "currency": acc.currency,
                "created_at": acc.created_at.isoformat()
            }
            for acc in accounts
        ]
    
    def create_user_account(self, user_id: int, name: str, account_type: str, currency: str = "INR") -> Dict:
        """Create new account for user"""
        
        account = Account(
            user_id=user_id,
            name=name,
            account_type=account_type,
            currency=currency
        )
        
        self.db.add(account)
        self.db.commit()
        self.db.refresh(account)
        
        return {
            "id": account.id,
            "name": account.name,
            "account_type": account.account_type,
            "currency": account.currency
        }
    
    def _transactions_to_dataframe(self, transactions: List[Transaction]) -> pd.DataFrame:
        """Convert transaction objects to pandas DataFrame"""
        data = []
        for txn in transactions:
            data.append({
                "id": txn.id,
                "date": txn.date,
                "amount": float(txn.amount),
                "merchant": txn.merchant,
                "raw_description": txn.raw_description or "",
                "currency": txn.currency,
                "category": txn.category.name if txn.category else None,
                "is_subscription": txn.is_subscription,
                "is_anomaly": txn.is_anomaly
            })
        
        return pd.DataFrame(data)
    
    def _empty_insights(self) -> Dict:
        """Return empty insights structure"""
        return {
            "total_spend": 0.0,
            "subscriptions_count": 0,
            "anomalies_count": 0,
            "projected_savings": 0.0,
            "category_breakdown": {},
            "monthly_trend": [],
            "transaction_count": 0,
            "avg_transaction_amount": 0.0
        }
    
    def _estimate_savings_potential(self, df: pd.DataFrame, subscriptions: Dict, anomalies: Dict) -> float:
        """Estimate potential savings (simplified calculation)"""
        
        # Potential from canceling subscriptions (assume 30% are cancellable)
        subscription_savings = sum(sub["avg_amount"] for sub in subscriptions.values()) * 0.3
        
        # Potential from reducing anomalous spending
        anomaly_savings = 0
        if anomalies:
            total_anomaly_excess = sum(
                max(0, anom["actual_amount"] - anom["group_median"]) 
                for anom in anomalies.values()
            )
            # Assume monthly reduction of 50% of anomaly excess
            anomaly_savings = (total_anomaly_excess / 6) * 0.5  # 6 months data, 50% reduction
        
        # Potential from category optimization (assume 10% reduction in discretionary)
        discretionary_categories = ["Food & Dining", "Shopping", "Entertainment"]
        discretionary_savings = 0
        
        if "predicted_category" in df.columns:
            discretionary_spend = df[
                df["predicted_category"].isin(discretionary_categories)
            ]["amount"].abs().sum()
            
            # Monthly discretionary savings (10% reduction)
            date_range = (df["date"].max() - df["date"].min()).days
            months = max(1, date_range / 30)
            monthly_discretionary = discretionary_spend / months
            discretionary_savings = monthly_discretionary * 0.1
        
        return subscription_savings + anomaly_savings + discretionary_savings
    
    def _save_plan_to_db(self, user_id: int, plan: Dict) -> int:
        """Save optimization plan to database"""
        
        plan_record = Plan(
            user_id=user_id,
            month=plan.get("target_month", datetime.now().strftime("%Y-%m")),
            savings_goal=Decimal(str(plan["savings_goal"])),
            projected_savings=Decimal(str(plan["projected_savings"])),
            is_active=True
        )
        
        self.db.add(plan_record)
        self.db.commit()
        self.db.refresh(plan_record)
        
        # Save plan actions
        for action in plan.get("actions", []):
            action_record = PlanAction(
                plan_id=plan_record.id,
                action_type=action["type"],
                target=action["target"],
                description=action["description"],
                save_amount=Decimal(str(action["save_amount"])),
                pain_score=Decimal(str(action.get("pain_score", 0)))
            )
            self.db.add(action_record)
        
        self.db.commit()
        
        return plan_record.id
