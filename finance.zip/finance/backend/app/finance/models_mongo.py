from typing import Dict, Any, Optional, List
from datetime import datetime
from pymongo.database import Database


class MongoReceipt:
    """Receipt document in MongoDB"""
    
    def __init__(self, db: Database):
        self.collection = db["receipts"]
    
    def create_receipt(self, user_id: int, transaction_id: int, data: Dict[str, Any]) -> str:
        """Create a receipt document"""
        receipt = {
            "user_id": user_id,
            "transaction_id": transaction_id,
            "file_path": data.get("file_path"),
            "file_name": data.get("file_name"),
            "file_type": data.get("file_type"),
            "ocr_text": data.get("ocr_text", ""),
            "extracted_data": data.get("extracted_data", {}),
            "created_at": datetime.utcnow(),
        }
        result = self.collection.insert_one(receipt)
        return str(result.inserted_id)
    
    def get_receipt(self, receipt_id: str) -> Optional[Dict[str, Any]]:
        """Get receipt by ID"""
        return self.collection.find_one({"_id": receipt_id})
    
    def get_receipts_by_user(self, user_id: int) -> List[Dict[str, Any]]:
        """Get all receipts for a user"""
        return list(self.collection.find({"user_id": user_id}))


class MongoModel:
    """ML models and artifacts storage"""
    
    def __init__(self, db: Database):
        self.collection = db["models"]
    
    def save_model_artifact(self, name: str, version: str, data: Dict[str, Any]) -> str:
        """Save model artifact (vectorizers, clusters, etc.)"""
        model_doc = {
            "name": name,
            "version": version,
            "data": data,
            "created_at": datetime.utcnow(),
        }
        result = self.collection.insert_one(model_doc)
        return str(result.inserted_id)
    
    def get_latest_model(self, name: str) -> Optional[Dict[str, Any]]:
        """Get latest version of a model"""
        return self.collection.find_one(
            {"name": name},
            sort=[("created_at", -1)]
        )


class MongoInsights:
    """Cached insights and analytics"""
    
    def __init__(self, db: Database):
        self.collection = db["insights_cache"]
    
    def cache_insights(self, user_id: int, key: str, data: Dict[str, Any], ttl_hours: int = 24) -> str:
        """Cache insights with TTL"""
        expires_at = datetime.utcnow().timestamp() + (ttl_hours * 3600)
        insight = {
            "user_id": user_id,
            "key": key,
            "data": data,
            "expires_at": expires_at,
            "created_at": datetime.utcnow(),
        }
        
        # Upsert based on user_id and key
        result = self.collection.replace_one(
            {"user_id": user_id, "key": key},
            insight,
            upsert=True
        )
        return str(result.upserted_id) if result.upserted_id else "updated"
    
    def get_cached_insights(self, user_id: int, key: str) -> Optional[Dict[str, Any]]:
        """Get cached insights if not expired"""
        current_time = datetime.utcnow().timestamp()
        result = self.collection.find_one({
            "user_id": user_id,
            "key": key,
            "expires_at": {"$gt": current_time}
        })
        return result["data"] if result else None
    
    def clear_user_cache(self, user_id: int):
        """Clear all cached insights for a user"""
        self.collection.delete_many({"user_id": user_id})
